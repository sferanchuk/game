
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include <string>
#include <vector>
#include <sstream>

//#include <windows.h>

using namespace std;

#include <SDL/SDL.h>

#include "g15.h"

SDL_Surface *loadSurface( const string& filename, bool back = false, bool mirror = false );
void LoadPhases( Person* person, const char *name );
void ShowDialog( int resource ) {};
void ShowTextDialog( const string& fname ) {};
void DoSendOption( Replica &r ) {};
void DoSendText( string text ) {};
void DoSendSetItem( Array &ar ) {};
int DoGo( Map& m, const string& person, Array& path, int point );
extern "C" int PlayMP3( const char *fname );
extern "C" int Silence();

static void Evaluate( World *world, Array& vars, Token *t, Data& d );
static World *theWorld;

Space *FindSpace( World *world, const string& name )
{
	for ( int sc = 0; sc < world->space.size(); sc++ )
	{
		if ( world->space[sc]->name ==  name ) return world->space[sc];
	}
	return 0;
}

Object *FindObject( World *world, const string& name )
{
	for ( int sc = 0; sc < world->object.size(); sc++ )
	{
		if ( world->object[sc]->name == name ) return world->object[sc];
	}
	Space *rv = FindSpace( world, name );
	if ( rv ) return rv;
	return 0;
}

MapObjectIter FindMapObject( World *world, const string& name )
{
	for ( MapObjectIter it = world->map.object.begin(); it != world->map.object.end(); it++ )
	{
		if ( (*it).name == name ) return it;
	}
	return world->map.object.end();
}

static int ToBool( Data &d )
{
	if ( d.type == dNumber ) return d.num;
	if ( d.type == dString ) return d.str.size();
	if ( d.type == dArray ) return d.array.data.size();
	return 0;
}

static int ToNum( Data &d )
{
	if ( d.type == dNumber ) return d.num;
	if ( d.type == dString ) return atol( d.str.data() );
	if ( d.type == dArray ) return d.array.data.size();
	return 0;
}

static string ToString( Data &d )
{
	ostringstream out;
	if ( d.type == dNumber ) out << d.num;
	if ( d.type == dString ) out << d.str;
	if ( d.type == dArray ) 
	{
		out << "{";
		for ( int fc = 0; fc < d.array.data.size(); fc++ )
		{
			out << d.array.data[fc].name;
			out << ":";
			out << ToString( *( d.array.data[fc].value) );
			out << ";";
		}
		out << "}";
	}
	return out.str();
}


int Find( Array &ar, const string& field, Data& d )
{
	for ( int fc = 0; fc < ar.data.size(); fc++ )
	{
		if ( ar.data[fc].name == field )
		{
			d = *( ar.data[fc].value );
			return 1;
		}
	}
	return 0;
}

int FindNumber( Array& ar, const string& field )
{
	Data d;
	if ( !Find( ar, field, d ) ) error( ( "field not found - " + field ).c_str() );
	if ( d.type != dNumber ) error( "Number expected" );
	return d.num;
}

string FindString( Array& ar, const string& field )
{
	Data d;
	if ( !Find( ar, field, d ) ) error( ( "field not found - " + field ).c_str() );
	if ( d.type != dString ) error( "String expected" );
	return d.str;
}

Token *FindSeq( Array& ar, const string& field )
{
	Data d;
	if ( !Find( ar, field, d ) ) error( ( "field not found - " + field ).c_str() );
	if ( d.type != dCode ) error( "Code expected" );
	return d.code;
}

Array *FindArray( Array& ar, const string& field )
{
	for ( int fc = 0; fc < ar.data.size(); fc++ )
	{
		if ( ar.data[fc].name == field )
		{
			
			if ( ar.data[fc].value->type != dArray ) error( ( "Array expected: " + field ).data() );
			return &( ( ar.data[fc].value->array ) );
		}
	}
 	error( ( "array ot found - " + field ).data() );	
}

static string GetId( Token *t, Array& vars )
{
	if ( t->type == tId ) return t->str;
	Data d;
	Evaluate( theWorld, vars, t, d );
	return ToString( d );
}

static void SetLValue( Array& ar, Token *t, Data& d, Array& vars )
{
	if ( t->type == tPoint )
	{
		Token *t0 = t->list[0];
		string field = GetId( t0, vars );
		for ( int ac = 0; ac < ar.data.size(); ac++ )
		{
			if ( ar.data[ac].name == field )
			{
				if ( ar.data[ac].value->type != dArray ) error( "array expected" );
				SetLValue( ar.data[ac].value->array, t->list[1], d, vars );
				return;
			}
		}
		ar.data.resize( ar.data.size() + 1 );
		ar.data.back().name = field;
		ar.data.back().value = new Data;
		ar.data.back().value->type = dArray;
		SetLValue( ar.data.back().value->array, t->list[1], d, vars );
		return;
	}
	string field = GetId( t, vars );
	for ( int ac = 0; ac < ar.data.size(); ac++ )
	{
		if ( ar.data[ac].name == field )
		{
			delete ar.data[ac].value;
			ar.data[ac].value = new Data( d );
			return;
		}
	}
	ar.data.resize( ar.data.size() + 1 );
	ar.data.back().name = field;
	ar.data.back().value = new Data( d );
	return;
}

static void Evaluate( World *world, Array& vars, Token *t, Data& d )
{
	if ( t->type == tAssign )
	{
		if ( t->list.size() < 2 ) error( "Incorrect =" );
		Data d1;
		Evaluate( world, vars, t->list[1], d1 );
		SetLValue( vars, t->list[0], d1, vars );
		return;
	}
	if ( t->type == tPoint )
	{
		if ( t->list.size() < 2 ) error( "Incorrect Point" );
		Data arg;
		Evaluate( world, vars, t->list[0], arg );
		if ( arg.type != dArray ) error( ( "Array expected: " + t->list[0]->str ).data() );
		Array *ar0 = &( arg.array );
		Token *pt = t->list[1];
		string field;
		do
		{
			if ( pt->type != tPoint ) 
			{
				field = GetId( pt, vars );
				break;
			}
			ar0 = FindArray( *ar0, GetId( pt->list[0], vars ) );
			pt = pt->list[1];
		}
		while ( 1 );
		if ( !Find( *ar0, field, d ) ) error( "Field not found" );
		return;
	}
	if ( t->type == tString )
	{
		d.type = dString;
		d.str = t->str;
		return;
	}
	if ( t->type == tNumber )
	{
		d.type = dNumber;
		d.num = t->num;
		return;
	}
	if ( t->type == tId )
	{
		if ( !Find( vars, t->str, d ) ) error( ("Variable not found: " + t->str).c_str() );
		return;
	}
	if ( t->type == tSequence )
	{
		//error( "Misplaced sequence" );
		d.type = dCode;
		d.code = t;
		return;
	}	
	// t->type == tFunction
	vector<Data> arg( t->list.size() );
	for ( int ac = 0; ac < t->list.size(); ac++ )
	{
		Evaluate( world, vars, t->list[ac], arg[ac] );
	}
	if ( t->str == "AddSpace" )
	{
		if ( arg.size() < 2 || arg[0].type != dString || arg[1].type != dString ) error( "AddSpace - e" );
		Space *space = new Space;
		space->file = arg[1].str;
		space->surface = loadSurface( space->file, true );
		space->offset = 0;
		space->name = arg[0].str;
		world->space.push_back( space );
		//world->object.push_back( space );
	}
	else if ( t->str == "AddGate" )
	{
		if ( arg.size() < 2 || arg[0].type != dArray || arg[1].type != dArray ) error( "AddGate - e" );
		Space *s1 = FindSpace( world, FindString( arg[0].array, "space" ) );
		if ( !s1 ) error( "Space not found" );
		Crossroad *cr1 = new Crossroad( 
			FindNumber( arg[0].array, "pos" ),
			FindNumber( arg[0].array, "height" ),
			s1 );
		cr1->top = FindNumber( arg[0].array, "top" );
		cr1->width = FindNumber( arg[0].array, "width" );
		world->object.push_back( cr1 );
		s1->object.push_back( cr1 );
		Space *s2 = FindSpace( world, FindString( arg[1].array, "space" ) );
		if ( !s2 ) error( "Space not found" );
		Crossroad *cr2 = new Crossroad( 
			FindNumber( arg[1].array, "pos" ),
			FindNumber( arg[1].array, "height" ),
			s2 );
		cr2->top = FindNumber( arg[1].array, "top" );
		cr2->width = FindNumber( arg[1].array, "width" );
		world->object.push_back( cr2 );
		s2->object.push_back( cr2 );
		cr1->conj = cr2;
		cr2->conj = cr1;
	}
	else if ( t->str == "AddObject" )
	{
		Map& m = world->map;
		if ( arg.size() < 1 || arg[0].type != dArray ) error( "AddObject - e" );
		MapObject mo;
		mo.name = FindString( arg[0].array, "name" );
		string type = FindString( arg[0].array, "type" );
		if ( m.repository.find( type ) == m.repository.end() ) error( "AddObject - undefined type" );
		mo.type = &( m.repository[type] );
		if ( mo.type->pic ) mo.pic = mo.type->pic;
		else mo.pic = mo.type->phase[0];
		mo.x = FindNumber( arg[0].array, "x" );
		mo.y = FindNumber( arg[0].array, "y" );
		Data before;
		if ( Find( arg[0].array, "before", before ) )
		{
			MapObjectIter it = FindMapObject( world, before.str );
			if ( it == m.object.end() ) error( "before - no object" );
			m.object.insert( it, mo );
		}
		else m.object.push_back( mo );
		/*
		SpaceObject *obj = new SpaceObject;
		obj->file = FindString( arg[0].array, "image" );
		obj->sprite = new Sprite( loadSurface( obj->file ) );
		obj->name = FindString( arg[0].array, "name" );
		obj->pos = FindNumber( arg[0].array, "pos" );
		obj->height = FindNumber( arg[0].array, "bottom" );// - obj->sprite->surface->h;
		Space *s = FindSpace( world, FindString( arg[0].array, "space" ) );
		if ( !s ) error( "space not found" );
		obj->space = s;
		s->object.push_back( obj );
		world->object.push_back( obj );
		*/
	}
	else if ( t->str == "MapMode" )
	{
		world->map.mode = arg[0].num;
	}
	else if ( t->str == "RemoveObject" )
	{
		MapObjectIter mo = FindMapObject( world, arg[0].str );
		if ( mo == world->map.object.end() ) error( "remove - no object" );
		world->map.object.erase( mo );
	}
		/*
		SpaceObject *o = (SpaceObject*)FindObject( world, arg[0].str );
		if ( !o ) error( "RemObj-e" );
		o->space->Remove( o );
		for ( int oc = 0; oc < world->object.size(); oc++ )
		{
			if ( world->object[oc] == o )
			{
				world->object.erase( world->object.begin() + oc );
				break;
			}
		}
		if ( world->current == o ) world->current = 0;
		delete o;
		*/
	else if ( t->str == "AddChoice" )
	{
		if ( arg.size() < 3 || arg[0].type != dString || arg[1].type != dString || arg[2].type != dNumber ) error( "AddChoice - e" );
		AddChoice( arg[0].str, arg[1].str, arg[2].num );
	}
	else if ( t->str == "GetChoice" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "GetChoice - e" );
		int value = GetChoice( arg[0].str );
		if ( value == -1 ) value = 2;
		d.type = dNumber;
		d.num = value;
	}
	else if ( t->str == "RemoveChoice" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "RemoveChoice - e" );
		RemoveChoice( arg[0].str );
	}
	else if ( t->str == "AddStatus" )
	{
		/*
		if ( arg.size() < 1 || arg[0].type != dArray) error( "AddStatus - e" );
		world->st.Add( FindString( arg[0].array, "code" ) );
		DoSendSetItem( arg[0].array );
		*/

	}
	else if ( t->str == "AddPerson" )
	{
		if ( arg.size() < 1 || arg[0].type != dArray ) error( "AddPerson - e" );
    	Person *p = new Person();
    	p->pos = FindNumber( arg[0].array, "pos" );
		p->name = FindString( arg[0].array, "name" );
		p->phases = FindString( arg[0].array, "phases" );
		p->text = FindString( arg[0].array, "text" );
    	p->w = FindNumber( arg[0].array, "width" );
    	p->height = 450;
    	p->pc = 0;
    	p->dir = true;
    	LoadPhases( p, p->phases.c_str() );
		Space *s = FindSpace( world, FindString( arg[0].array, "space" ) );
		if ( !s ) error( "space not found" );
		p->space = s;
		s->object.push_back( p );
		world->object.push_back( p );
    }
	else if ( t->str == "AddRule" )
	{
		if ( arg.size() < 2 || arg[0].type != dString || arg[1].type != dArray ) error( "AddRule - e" );
    	Person *p = (Person*) FindObject( world, arg[0].str );
    	Rule *r = new Rule;
    	r->cond = FindSeq( arg[1].array, "cond" );
		r->action = FindSeq( arg[1].array, "action" );
		r->result.name = FindString( arg[1].array, "result" );
    	r->weight = FindNumber( arg[1].array, "weight" );
    	r->wait = FindNumber( arg[1].array, "wait" );
		p->rule.push_back( r );
    }
	else if ( t->str == "GetObject" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "GetObject - e" );
		Object *o = FindObject( world, arg[0].str );
		if ( !o ) error( ( "object not found: " + arg[0].str ).c_str() );
		d.type = dArray;
		o->GetAttr( d.array );
	}
	else if ( t->str == "SetAttr" )
	{
		if ( arg.size() < 3 || arg[0].type != dString || arg[1].type != dString ) error( "SetAttr - e" );
		MapObjectIter mo = FindMapObject( world, arg[0].str );
		if ( mo == world->map.object.end() ) error( "set attr - no object" );
		if ( arg[1].str == "x" ) (*mo).x = arg[2].num;
		else if ( arg[1].str == "y" ) (*mo).y = arg[2].num;
		else if ( arg[1].str == "dir" ) (*mo).dir = arg[2].num;
		else if ( arg[1].str == "phase" ) 
		{
			if ( arg[2].type != dNumber || arg[2].num >= (*mo).type->phase.size() ) error( "SetAttr - incorrect phase" );
			(*mo).pic = (*mo).type->phase[ arg[2].num ];
		}
	}
	else if ( t->str == "SetAim" )
	{
		if ( arg.size() < 3 || arg[0].type != dString || arg[1].type != dString || arg[2].type != dNumber ) error( "SetAim - e" );
		Person *p = (Person*) FindObject( world, arg[0].str );
		if ( !p ) error( ( "person not found: " + arg[0].str ).c_str() );
		Aim a;
		a.predicate.name = arg[1].str;
		a.weight = arg[2].num;
		int ac;
		for ( ac = 0; ac < p->aim.size(); ac++ )
		{
			if ( p->aim[ac].predicate == a.predicate )
			{
				p->aim[ac].weight = a.weight;
				break;
			}
		}
		if ( ac == p->aim.size() ) p->aim.push_back( a );
	}
	else if ( t->str == "SetCond" )
	{
		Person *p;
		string name;
		if ( arg.size() < 1 || arg[0].type != dString ) error( "SetCond - e" );
		if ( arg.size() == 1 ) 
		{
			p = world->curPerson;
			name = arg[0].str;
		}
		else
		{
			p = (Person*) FindObject( world, arg[0].str );
			name = arg[1].str;
		}
		Predicate pr;
		pr.name = name;
		int sc;
		for ( sc = 0; sc < p->state.size(); sc++ )
		{
		 	if ( p->state[sc] == pr ) break;
		}
		if ( sc == p->state.size() ) p->state.push_back( pr );
	}
	else if ( t->str == "RemoveCond" )
	{
		Person *p;
		string name;
		if ( arg.size() < 1 || arg[0].type != dString ) error( "RemoveCond - e" );
		if ( arg.size() == 1 ) 
		{
			p = world->curPerson;
			name = arg[0].str;
		}
		else
		{
			p = (Person*) FindObject( world, arg[0].str );
			name = arg[1].str;
		}
		Predicate pr;
		pr.name = name;
		int sc;
		for ( sc = 0; sc < p->state.size(); sc++ )
		{
		 	if ( p->state[sc] == pr ) break;
		}
		if ( sc != p->state.size() ) p->state.erase( p->state.begin() + sc );
	}
	else if ( t->str == "GetCurrent" )
	{
		d.type = dArray;
		if ( world->current ) world->current->GetAttr( d.array );
	}
	else if ( t->str == "GetReply" )
	{
		d.type = dNumber;
		if ( world->reply != -1 ) 
		{
			d.num = world->reply;
			world->reply = -1;
		}
		else d.num = 0;
	}
	else if ( t->str == "GetUsed" )
	{
		d.type = dString;
		d.str = world->usedItem;
	}
	else if ( t->str == "SetCurrent" )
	{
		if ( arg[0].type == dNumber && arg[0].num == 0 ) world->current = 0;
		else if ( arg[0].type == dString ) world->current = FindObject( world, arg[0].str );
	}
	else if ( t->str == "SetUsed" )
	{
		world->usedItem = "";
	}
	else if ( t->str == "Run" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "e" );
		for ( int sc = 0; sc < world->script->list.size(); sc++ )
		{
			if ( world->script->list[sc]->str == arg[0].str )
			{
				Stack *stack = new Stack;
				stack->vars.AddGlobals( &(world->globals) );
				stack->push( sPos, world->script->list[sc] );
				for ( int ac = 1; ac < arg.size(); ac++ )
				{
					if ( t->list[ac]->type != tId )
					{
						error( "only named variables are allowed as function arguments" );
					}
					stack->vars.Add( t->list[ac]->str, new Data( arg[ac] ) );
				}
				world->sample.push_back( stack );
			}
			//RunScript( this, stack );
		}
		/*
		for ( int sc = 0; sc < world->sample.size(); sc++ )
		{
			if ( world->sample[sc]->name == arg[0].str )
			{
				world->sample[sc]->active = 1;
			}
		}
		*/
	}
	else if ( t->str == "Delay" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "e" );
		for ( int sc = 0; sc < world->sample.size(); sc++ )
		{
			if ( world->sample[sc]->name == arg[0].str )
			{
				world->sample[sc]->active = 0;
			}
		}
	}
	else if ( t->str == "Id" )
	{
		if ( arg.size() < 1 ) error( "Id- e" );
		d = arg[0];
	}
	else if ( t->str == "Str" )
	{
		if ( arg.size() < 1 ) error( "Str - e" );
		d.type = dString;
		d.str = ToString( arg[0] );
	}
	else if ( t->str == "Size" )
	{
		if ( arg.size() < 1 ) error( "Size - e" );
		d.type = dNumber;
		d.num = ToBool( arg[0] );
	}
	else if ( t->str == "Num" )
	{
		if ( arg.size() < 1 ) error( "Num - e" );
		d.type = dNumber;
		d.num = ToNum( arg[0] );
	}
	else if ( t->str == "Not" )
	{
		if ( arg.size() < 1 ) error( "Not - e" );
		d.type = dNumber;
		d.num = !ToBool( arg[0] );
	}
	else if ( t->str == "And" )
	{
		if ( arg.size() < 2 ) error( "And - e" );
		d.type = dNumber;
		d.num = ToBool( arg[0] ) && ToBool( arg[1] );
	}
	else if ( t->str == "Or" )
	{
		if ( arg.size() < 2 ) error( "Or - e" );
		d.type = dNumber;
		d.num = ToBool( arg[0] ) || ToBool( arg[1] );
	}
	else if ( t->str == "EQ" )
	{
		if ( arg.size() < 2 || arg[0].type != arg[1].type ) error( "EQ - e" );
		d.type = dNumber;
		d.num = ( arg[0].type == dNumber ) ? arg[0].num == arg[1].num :
		        ( arg[0].type == dString ) ? arg[0].str == arg[1].str : 0;
	}
	else if ( t->str == "NE" )
	{
		if ( arg.size() < 2 || arg[0].type != arg[1].type ) error( "NE - e" );
		d.type = dNumber;
		d.num = ( arg[0].type == dNumber ) ? arg[0].num != arg[1].num :
		        ( arg[0].type == dString ) ? arg[0].str != arg[1].str : 0;
	}
	else if ( t->str == "GT" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Comp - e" );
		d.type = dNumber;
		d.num = arg[0].num > arg[1].num;
	}
	else if ( t->str == "GE" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Comp - e" );
		d.type = dNumber;
		d.num = arg[0].num >= arg[1].num;
	}
	else if ( t->str == "LT" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Comp - e" );
		d.type = dNumber;
		d.num = arg[0].num < arg[1].num;
	}
	else if ( t->str == "LE" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Comp - e" );
		d.type = dNumber;
		d.num = arg[0].num <= arg[1].num;
	}
	else if ( t->str == "Plus" )
	{
		if ( arg.size() == 2 && arg[0].type == dNumber && arg[1].type == dNumber ) 
		{
			d.type = dNumber;
			d.num = arg[0].num + arg[1].num;
		}
		else if ( arg.size() == 2 && arg[0].type == dString && arg[1].type == dString ) 
		{
			d.type = dString;
			d.str = arg[0].str + arg[1].str;
		}
		else error( "Plus - e" );
	}
	else if ( t->str == "Minus" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Minus - e" );
		d.type = dNumber;
		d.num = arg[0].num - arg[1].num;
	}
	else if ( t->str == "Mult" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Plus - e" );
		d.type = dNumber;
		d.num = arg[0].num * arg[1].num;
	}
	else if ( t->str == "Div" )
	{
		if ( arg.size() < 2 || arg[0].type != dNumber || arg[1].type != dNumber ) error( "Minus - e" );
		d.type = dNumber;
		d.num = arg[0].num / arg[1].num;
	}
	else if ( t->str == "Random" )
	{
		if ( arg.size() < 1 || arg[0].type !=  dNumber ) error( "Random - e" );
		d.type = dNumber;
		d.num = rand() % arg[0].num;
	}
	else if ( t->str == "Trial" )
	{
		if ( arg.size() < 4 ) error( "Trial - e" );
		d.type = dNumber;
		double value = sin( double( arg[0].num ) / arg[1].num );
		d.num = ( rand() * value * value  / RAND_MAX 
			> double( arg[3].num - arg[2].num ) / arg[3].num );
	}
	else if ( t->str == "Near" )
	{
		if ( arg.size() < 2 || arg[0].type != dArray || arg[1].type != dArray ) error( "e" );
		int dist = ( arg.size() < 3 ) ? 2 : ToNum( arg[2] );
		d.type = dNumber;
    	d.num = ( abs( 
    		FindNumber( arg[0].array, "x" ) 
    		- FindNumber( arg[1].array, "x" ) ) < dist
    		&& abs ( 
			FindNumber( arg[0].array, "y" ) 
    		- FindNumber( arg[1].array, "y" ) ) < dist );
	}
	else if ( t->str == "MapObject" )
	{
		MapObjectIter mo = FindMapObject( world, arg[0].str );
		if ( mo == world->map.object.end() ) error( "no map object" );
		Data x;	x.type = dNumber; x.num = (*mo).x;
		Data y;	y.type = dNumber; y.num = (*mo).y;
		d.type = dArray;
		d.array.Add( "x", new Data( x ) );
		d.array.Add( "y", new Data( y ) );
	}
	else if ( t->str == "Inside" )
	{
		if ( arg.size() < 2 || arg[0].type != dArray || arg[1].type != dArray ) error( "e" );
		d.type = dNumber;
    	d.num = ( FindNumber( arg[0].array, "pos" ) 
    		> FindNumber( arg[1].array, "pos" )
    		&& FindNumber( arg[0].array, "pos" )
    		+ FindNumber( arg[0].array, "width" )
    		< FindNumber( arg[1].array, "pos" )
    		+ FindNumber( arg[1].array, "width" ) );
	}
	else if ( t->str == "Visible" )
	{
		int x;
		int y;
		if ( arg.size() == 1 && arg[0].type == dString )
		{
			MapObjectIter mo = FindMapObject( world, arg[0].str );
			if ( mo == world->map.object.end() ) error( "visible - no object" );
			x = (*mo).x;
			y = (*mo).y;
		}
		else if ( arg.size() == 2 && arg[0].type == dNumber && arg[1].type == dNumber )
		{
			x = arg[0].num;
			y = arg[1].num;
		}
		else error( "visible - no point" ); 
		SpaceObject *o = (SpaceObject*)FindObject( world, arg[0].str );
		d.type = dNumber;
		d.num = 
			abs( world->map.player->x - x ) < visibleSize
			&& abs( world->map.player->y - y ) < visibleSize;
	}
	else if ( t->str == "Go" )
	{
		if ( arg.size() < 3 || arg[0].type != dString || arg[1].type != dArray || arg[2].type != dNumber ) error( "Go - e" );
		/*
		Object *o = FindObject( world, arg[0].str );
		if ( !o ) error( "object not found" );
		Object *s = FindSpace( world, arg[1].str );
		if ( !o ) error( "space not found" );
		((Person*)o)->Go( (Space*)s, arg[2].num );
		*/
		d.type = dNumber;
		d.num = DoGo( world->map, arg[0].str, arg[1].array, arg[2].num );
	}
	else if ( t->str == "Jump" )
	{
		if ( arg.size() < 3 || arg[0].type != dString || arg[1].type != dString || arg[2].type != dNumber ) error( "Go - e" );
		SpaceObject *o = (SpaceObject*) FindObject( world, arg[0].str );
		if ( !o ) error( "object not found" );
		Space *s = FindSpace( world, arg[1].str );
		if ( !s ) error( "space not found" );
		o->space->Remove( o );
		s->object.push_back( o );
		o->space = s;
		o->pos = arg[2].num;
	}
	else if ( t->str == "Sit" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "e" );
		Object *o = FindObject( world, arg[0].str );
		((Person*)o)->Sit();
	}
	else if ( t->str == "Lay" )
	{
		if ( arg.size() < 1 || arg[0].type != dString ) error( "e" );
		Object *o = FindObject( world, arg[0].str );
		((Person*)o)->Lay();
	}
	else if ( t->str == "Say" )
	{
		if ( arg.size() < 3 || arg[0].type != dNumber || arg[1].type != dNumber || arg[2].type != dString ) error( "Say - e" );
		int height = 200;
		if ( arg.size() > 3 ) height = arg[3].num;
		world->to.Say( arg[0].num - world->player->space->offset, 
			height, 
			arg[1].num, 
			arg[2].str.c_str() );
	}
	else if ( t->str == "Option" )
	{
		if ( arg.size() < 2 || arg[0].type != dString || arg[1].type != dString ) error( "Option - e" );
		Replica r;
		r.rec = arg[0].str;
		r.text = arg[1].str;
		if ( arg.size() > 2 ) r.bet = arg[2].num; else r.bet = 0;
		if ( arg.size() > 3 ) r.alc = arg[3].num; else r.alc = 0;
		if ( arg.size() > 4 ) r.sign = arg[4].num; else r.sign = world->ro.list.size() + 1;
		DoSendOption( r );
	}
	else if ( t->str == "Text" )
	{
		if ( arg.size() < 2 || arg[0].type != dString || arg[1].type != dString ) error( "Text - e" );
		int bet = 0;
		if( arg.size() == 3 ) bet = arg[2].num;
		Object *o = FindObject( world, arg[0].str );
		((Person*)o)->ChangeTerritory( "robert", bet );
		((Person*)o)->territory -= bet;
		world->player->ChangeTerritory( arg[0].str, bet );
		string msg = "(" + ((Person*)o)->text + ") " + arg[1].str;
		if ( bet != 0 )
		{
			char buf[10];
			sprintf( buf, "(%d)", bet );
			msg += buf;
		}
		msg += "\r\n";
		DoSendText( msg );
	}
	else if ( t->str == "PText" )
	{
		if ( arg.size() < 2 || arg[0].type != dString || arg[1].type != dString ) error( "Text - e" );
		int bet = 0;
		if( arg.size() == 3 ) bet = arg[2].num;
		Object *o = FindObject( world, arg[0].str );
		((Person*)o)->ChangeTerritory( "robert", bet );
		world->player->territory -= bet;
		world->player->ChangeTerritory( arg[0].str, bet );
		string msg = "(������) " + arg[1].str;;
		if ( bet != 0 )
		{
			char buf[10];
			sprintf( buf, "(%d)", bet );
			msg += buf;
		}
		msg += "\r\n";
		DoSendText( msg );
	}
	else if ( t->str == "NewDlg" )
	{
   		DoSendText( "-----\r\n" );
   	}
	else if ( t->str == "Play" )
	{
		//Silence();
		PlayMP3( ( "sound/"+arg[0].str ).c_str() );
	}
	else if ( t->str == "Silence" )
	{
    	Silence();
    }
	else if ( t->str == "MessageBox" )
	{
	    /*
		SDL_ShowCursor( 1 );
		MessageBox( 0, arg[0].str.c_str(), "g15", MB_OK );
		SDL_ShowCursor( 0 );
		*/
	}
	else if ( t->str == "Dump" )
	{
		fprintf( stderr, arg[0].str.data() );
	}
	else if ( t->str == "Print" )
	{
		PrintMessage( arg[0].str.data() );
	}
	else if ( t->str == "Question" )
	{
	    /*
		d.type = dNumber;
		SDL_ShowCursor( 1 );
    	d.num =	MessageBox( 0, arg[0].str.c_str(), "g15", MB_YESNO ) == IDYES;
		SDL_ShowCursor( 0 );
		*/
	}
	else if ( t->str == "Dialog" )
	{
		SDL_ShowCursor( 1 );
		ShowDialog( arg[0].num );
		SDL_ShowCursor( 0 );
	}
	else if ( t->str == "TextDialog" )
	{
		SDL_ShowCursor( 1 );
		ShowTextDialog( arg[0].str );
		SDL_ShowCursor( 0 );
	}
	else error( ( "Unknown function " + t->str ).c_str() );
}

static int Step( World *world, Stack& stack )
{
	theWorld = world;
	StackItem& si = stack.back();
	if ( si.type == sPos )
	{
		if ( si.token->type != tSequence ) 
		{
			if ( si.pos == 0 )
			{
				stack.push( sToken, si.token );
				( stack.list.end() - 2 )->pos++;
				return 0;
			}
			stack.pop();
			return 0;
		}
		if ( si.token->list.size() <= si.pos )
		{
			stack.pop();
			if ( !stack.list.size() ) return 1;
			return 0;
		}
		stack.push( sToken, si.token->list[ si.pos ] );
		( stack.list.end() - 2 )->pos++;
		return 0;
	}
	if ( si.token->type == tFunction )
	{
		string fname = si.token->str;
		if ( fname == "Pause" )
		{
			if ( !si.token->list.size() || si.pos >= si.token->list[0]->num )
				stack.pop();
			else si.pos++;
			return 2;
		}
		if ( fname == "If" )
		{
			StackItem sb = si;
			stack.pop();
			Data d;
			Evaluate( world, stack.vars, sb.token->list[0], d );
			if ( ToBool( d ) )
			{
				if ( sb.token->list.size() > 1 )
				{
					stack.push( sPos, sb.token->list[1] );
					return 0;
				}
			}
			else
			{
				if ( sb.token->list.size() > 2 )
				{
					stack.push( sPos, sb.token->list[2] );
					return 0;
				}
			}
			return 0;
		}
		if ( fname == "While" )
		{
			StackItem sb = si;
			Data d;
			Evaluate( world, stack.vars, sb.token->list[0], d );
			if ( ToBool( d ) )
			{
				if ( sb.token->list.size() > 1 )
				{
					stack.push( sPos, sb.token->list[1] );
					return 0;
				}
			}
			else stack.pop();
			return 0;
		}
		if ( fname == "Continue" || fname == "Break" )
		{
			do
			{
				if ( !stack.list.size() ) error( "No While for Break or Continue" );
				if ( stack.back().type == sToken 
					&& stack.back().token->str == "While" ) break;
				stack.pop();
			}
			while ( true );
			if ( fname == "Break" ) stack.pop();
			return 0;
		}
		if ( fname == "Return" )
		{
			return 1;
		}
	}
	Data d;
	Evaluate( world, stack.vars, si.token, d );
	stack.pop();
	return 0;
}

int RunScript( World *world, Stack& stack )
{
	do
	{
		int rv = Step( world, stack );
		if ( rv != 0 ) return rv;
	}
	while ( true );
}

int Array::Save( FILE *ofile )
{
	int size = data.size();
	fwrite( &size, 1, sizeof( int ), ofile );
	for ( int vc = 0; vc < size; vc++ )
	{
		SaveString( data[vc].name, ofile );
		fwrite( &( data[vc].value->type ), 1, sizeof( int ), ofile );
		switch ( data[vc].value->type )
		{
			case dNumber:
         		fwrite( &( data[vc].value->num ), 1, sizeof( int ), ofile );
         		break;

			case dString:
         		SaveString( data[vc].value->str, ofile );
         		break;

			case dArray:
         		data[vc].value->array.Save( ofile );
         		break;
     	}
    }
}

int Array::Load( FILE *ifile )
{
	int size;
	fread( &size, 1, sizeof( int ), ifile );
	data.resize( size );
	for ( int vc = 0; vc < size; vc++ )
	{
		ReadString( data[vc].name, ifile );
		data[vc].value = new Data;
		fread( &( data[vc].value->type ), 1, sizeof( int ), ifile );
		switch ( data[vc].value->type )
		{
			case dNumber:
         		fread( &( data[vc].value->num ), 1, sizeof( int ), ifile );
         		break;

			case dString:
         		ReadString( data[vc].value->str, ifile );
         		break;

			case dArray:
         		data[vc].value->array.Load( ifile );
         		break;
     	}
    }
    return 1;
}

Token *FindToken( Token *t, int code )
{
	if ( t->code == code ) return t;
	
	for ( int tc = 0; tc < t->list.size(); tc++ )
	{
		Token *rv = FindToken( t->list[tc], code );
		if ( rv ) return rv;
	}
	return 0;
}

int Stack::Save( FILE *ofile )
{
	int size = list.size();
	fwrite( &size, 1, sizeof( int ), ofile );
	for ( int ic = 0; ic < size; ic++ )
	{
		fwrite( &(list[ic].type), 1, sizeof( int ), ofile );
		fwrite( &(list[ic].token->code), 1, sizeof( int ), ofile );
		fwrite( &(list[ic].pos), 1, sizeof( int ), ofile );
	}
	vars.Save( ofile );
	SaveString( name, ofile );
	fwrite( &active, 1, sizeof( int ), ofile );

}

int Stack::Load( FILE *ifile, Token *t )
{
	int size;
	fread( &size, 1, sizeof( int ), ifile );
	list.resize( size );
	for ( int ic = 0; ic < size; ic++ )
	{
		fread( &(list[ic].type), 1, sizeof( int ), ifile );
		int code;
		fread( &code, 1, sizeof( int ), ifile );
		list[ic].token = FindToken( t, code );
		fread( &(list[ic].pos), 1, sizeof( int ), ifile );
	}
	vars.Load( ifile );
	ReadString( name, ifile );
	fread( &active, 1, sizeof( int ), ifile );
}
