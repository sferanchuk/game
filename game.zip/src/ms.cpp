
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <string>
#include <vector>

using namespace std;

#include <SDL/SDL.h>

#include "g15.h"

enum { lId, lString, lNumber, lSymb, lEOF };

struct Lexema
{
	int type;
	string str;
	int num;
	int symb;
};

int line = 0;

bool NextLexema( Lexema& l, FILE *ifile )
{
	char *sep = " \n\t\r";
	char *symb = ".(){}=,;";
	char *dig = "0123456789";
   	
   	int c;
   	do
   	{
    	c = getc( ifile );
    	if ( c == -1 ) 
    	{
    		l.type = lEOF;
    		return false;
    	}
    	if ( c == '#' )
    	{
    		do
    		{
    			c = getc( ifile );
    			if ( c == -1 ) 
    			{
    				l.type = lEOF;
    				return false;
    			}
    		}
    		while ( c != '\n' );
    		line++;
    		continue;
    	}
    	if ( strchr( sep, c ) ) 
    	{
    		if ( c == '\n' ) line++;
    		continue;
    	}
    	if ( strchr( symb, c ) )
    	{
    		l.type = lSymb;
    		l.symb = c;
    		return true;
    	}
    	if ( c == '"' )
    	{
    	    l.str = "";
    		do
    		{
    			c = getc( ifile );
    			if ( c == -1 ) 
    			{
    				l.type = lEOF;
    				return false;
    			}
    			if ( c == '"' ) break;
    			if ( c == '\\' )
    			{
    				c = getc( ifile );
    				if ( c == 'n' ) c = '\n';
    			}
    			l.str.push_back( c );
    		}
    		while ( true );
    		l.type = lString;
    		return true;
    	}
    	if ( strchr( dig, c ) )
    	{
    		l.num = c - '0';
    		do
    		{
    			c = getc( ifile );
    			if ( strchr( dig, c ) ) l.num = l.num * 10 + c - '0';
    			else break;
    		}
    		while ( true );
    		fseek( ifile, -1, SEEK_CUR );
    		l.type = lNumber;
    		return true;
    	}
    	break;
    }
    while ( true );
    l.str = "";
    l.str.push_back( c );
    do
    {
    	c = getc( ifile );
    	if ( c == -1 ) 
    	{
    		l.type = lEOF;
    		return false;
    	}
    	if ( strchr( sep, c ) ) break;
    	if ( strchr( symb, c ) )
    	{
    		fseek( ifile, -1, SEEK_CUR );
    		break;
    	}
    	l.str.push_back( c );
    }
    while ( true );
    l.type = lId;
	return true;
}

Token *parseSeq( Lexema& next, FILE *ifile );
Token *parseAssign( Lexema& next, FILE *ifile );

Token *parseFunction( Lexema& next, FILE *ifile )
{
	Lexema l;
	NextLexema( l, ifile );
	if ( l.type == lString )
	{
		Token *rv = new Token;
		rv->type = tString;
		rv->str = l.str;
		NextLexema( next, ifile );
		return rv;
	}
	if ( l.type == lNumber )
	{
		Token *rv = new Token;
		rv->type = tNumber;
		rv->num = l.num;
		NextLexema( next, ifile );
		return rv;
	}
	if ( l.type == lSymb && l.symb == '{' )
	{
		return parseSeq( next, ifile );
	}
	if ( l.type == lSymb && ( l.symb == ')' || l.symb == '}' || l.symb == ';' ) )
	{
		next = l;
		return 0;
	}
	if ( l.type != tId ) error( "id expected" );
	
	NextLexema( next, ifile );

	if ( next.type == lSymb && next.symb == '(' )
	{
		Token *rv = new Token;
		rv->type = tFunction;
		rv->str = l.str;
		do
		{
			Token *a = parseAssign( next, ifile );
			if ( next.type == lSymb && next.symb == ')' )
			{
				if ( a ) rv->list.push_back( a );
				NextLexema( next, ifile );
				return rv;
			}
			if ( next.type != lSymb || next.symb != ',' ) error( ", or ) expected" );
			rv->list.push_back( a );
		}
		while ( 1 );
	}
	Token *rv = new Token;
	rv->type = tId;
	rv->str = l.str;
	return rv;
}

Token *parsePoint( Lexema& next, FILE *ifile )
{
	Token *t = parseFunction( next, ifile );
	if ( next.type == lSymb && next.symb == '.' )
	{
		Token *t1 = parsePoint( next, ifile );
		Token *rv = new Token;
		rv->type = tPoint;
		rv->list.push_back( t );
		rv->list.push_back( t1 );
		return rv;
	}
	return t;
}

Token *parseAssign( Lexema& next, FILE *ifile )
{
	Token *t = parsePoint( next, ifile );
	if ( next.type == lSymb && next.symb == '=' )
	{
		Token *t1 = parsePoint( next, ifile );
		Token *rv = new Token;
		rv->type = tAssign;
		rv->list.push_back( t );
		rv->list.push_back( t1 );
		return rv;
	}
	return t;
}

Token *parseSeq( Lexema& next, FILE *ifile )
{
	Token *rv = new Token;
	rv->type = tSequence;
	do
	{
		Token *t = parseAssign( next, ifile );
		if ( next.type == lSymb && next.symb == ';' )
		{
			if ( t ) rv->list.push_back( t );
			continue;
		}
		if ( next.type == lSymb && next.symb == '}' )
		{
			if ( t ) rv->list.push_back( t );
			NextLexema( next, ifile );
			return rv;
		}
		error( "; expected" );
	}
	while ( true );
}

int SaveString( string& str, FILE *ofile )
{
	short int size = str.size();
	fwrite( &size, 1, sizeof( short int ), ofile );
	fwrite( str.data(), size, 1, ofile );
	return 1;
}

int ReadString( string& str, FILE *ifile )
{
	str = "";
	short int size;
	fread( &size, 1, sizeof( short int ), ifile );
	for ( int lc = 0; lc < size; lc++ )
	{
		int c = getc( ifile );
		if ( c == -1 ) return 0;
		str.push_back( c );
	}
	return 1;
}

int SaveToken( Token *t, FILE *ofile )
{
	fwrite( &t->code, 1, sizeof( int ), ofile );
	fwrite( &t->type, 1, sizeof( int ), ofile );
	SaveString( t->str, ofile );
	fwrite( &t->num, 1, sizeof( int ), ofile );
	short int size = t->list.size();
	fwrite( &size, 1, sizeof( short int ), ofile );
	for ( int tc = 0; tc < size; tc++ )
	{
		SaveToken( t->list[tc], ofile );
	}
	return 1;
}

int LoadToken( Token *t, FILE *ifile )
{
	fread( &t->code, 1, sizeof( int ), ifile );
	fread( &t->type, 1, sizeof( int ), ifile );
	if ( !ReadString( t->str, ifile ) ) return 0;
	fread( &t->num, 1, sizeof( int ), ifile );
	short int size;
	fread( &size, 1, sizeof( short int ), ifile );
	for ( int tc = 0; tc < size; tc++ )
	{
		Token *nt = new Token;
		if ( !LoadToken( nt, ifile ) ) return 0;
		t->list.push_back( nt );
	}
	return 1;
}

static int tcounter = 0;

Token::Token()
{
	code = tcounter++;
}

Token::~Token()
{
	for ( int tc = 0; tc < list.size(); tc++ )
		delete list[tc];
}

Token *LoadScript()
{
	FILE *ifile = fopen( "game.ms", "rt" );
	Token *res = new Token;
	Lexema l;
	NextLexema( l, ifile );
	do
	{
		if ( l.type == lEOF ) break;
		string name = l.str;
		Lexema l1;
		NextLexema( l1, ifile );
		if ( l1.type != lSymb || l1.symb != '{' ) error( "{ expected" );
		Token *t = parseSeq( l, ifile );
		t->str = name;
		res->list.push_back( t );
	}
	while( 1 );
	fclose( ifile );
	return res;
}
