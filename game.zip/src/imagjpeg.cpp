// from orig. wx code by Robert Roebling

#include <string.h>

#include <SDL/SDL.h>
extern "C" {
#include "jpeglib.h"
}

/*
METHODDEF(void)
my_error_exit (j_common_ptr cinfo)
{
	printf( "Error reading JPEG" );
	exit( 0 );
}
*/

SDL_Surface *SDL_LoadJPEG( const char *fname )
{
	FILE *ifile = fopen( fname, "rb" );
    struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr error_mgr;
    cinfo.err = jpeg_std_error( &error_mgr );
    jpeg_create_decompress( &cinfo );
    jpeg_stdio_src( &cinfo, ifile );
    jpeg_read_header( &cinfo, TRUE );
    cinfo.out_color_space = JCS_RGB;
    cinfo.quantize_colors = FALSE;
    jpeg_start_decompress( &cinfo );
    int w, h;
    int npixels;

    w = cinfo.image_width;
    h = cinfo.image_height;

    npixels = w * h;
	SDL_Surface *rv = SDL_CreateRGBSurface( SDL_SWSURFACE, w, h, 24, 0, 0, 0, 0 );
	Uint8 *ptr = (Uint8*) rv->pixels;// + ( h - 1 ) * rv->pitch;
    JSAMPARRAY tempbuf;
    int stride = cinfo.output_width * 3;
    tempbuf = (*cinfo.mem->alloc_sarray)
        ((j_common_ptr) &cinfo, JPOOL_IMAGE, stride, 1 );
	int pos = 0;
    for (int i = 0; i < h; i++)
    {
		Uint8 *prevPtr = ptr;
		jpeg_read_scanlines( &cinfo, tempbuf, 1 );
		memcpy( ptr, tempbuf[0], w * 3 );
		for ( int wc = 0; wc < w; wc++ )
		{
			Uint8 t = ptr[ wc * 3 ];
			ptr[ wc * 3 ] = ptr[ wc * 3 + 2 ];
			ptr[ wc * 3 + 2 ] = t;
		}
        ptr = prevPtr + rv->pitch;
    }
    jpeg_finish_decompress( &cinfo );
    jpeg_destroy_decompress( &cinfo );
    fclose( ifile );
	return rv;
}
