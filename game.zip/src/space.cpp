
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <string>
#include <vector>
#include <set>

using namespace std;

#include <SDL/SDL.h>

#include "g15.h"

extern SDL_Surface *screen;
//extern SDL_Cursor *cursor[];
extern int cursX, cursY;
extern int cursNum;
extern bool button;

SDL_Surface *loadSurface( const string& filename, bool back = false, bool mirror = false );
int match( SDL_Surface *screen, SDL_Surface *image, int xpos, int ypos, int x, int y );

int Crossroad::Load( FILE *ifile, World *world )
{
	if ( !SpaceObject::Load( ifile, world ) ) return 0;
	fread( &top, 1, sizeof( int ), ifile );
	fread( &width, 1, sizeof( int ), ifile );
	if ( !ReadString( cname, ifile ) ) return 0;
	Space *cs = FindSpace( world, cname );
	if ( !cs ) return 0;
	conj = 0;
	for ( int oc = 0; oc < cs->object.size(); oc++ )
	{
		if ( cs->object[oc]->type == "gate" )
		{
			Crossroad *cconj = (Crossroad*)( cs->object[oc] );
			if ( cconj->cname == space->name && !cconj->conj )
			{
				conj = cconj;
				cconj->conj = this;
				break;
			}
		}
	}
	return 1;
}

int Crossroad::Save( FILE *ofile )
{
	SpaceObject::Save( ofile );
	fwrite( &top, 1, sizeof( int ), ofile );
	fwrite( &width, 1, sizeof( int ), ofile );
	SaveString( conj->space->name, ofile );
}

int Crossroad::SetAttr( Attribute *a )
{
	SpaceObject::SetAttr( a );
}

int Crossroad::GetAttr( Array& a )
{
	static int rc = 0;
	SpaceObject::GetAttr( a );
	if ( rc == 0 )
	{
		rc++;
		Array c;
		conj->GetAttr( c );
		rc--;
		a.Add( "conj", new Data( c ) );
	}
}


int Space::Load( FILE *ifile, World *world )
{
	if ( !Object::Load( ifile, world ) ) return 0;
	ReadString( file, ifile );
	surface = loadSurface( file, true );
	fread( &offset, 1, sizeof( int ), ifile );
	fread( &dest, 1, sizeof( int ), ifile );
	return 1;
}

int Space::Save( FILE *ofile )
{
	Object::Save( ofile );
	SaveString( file, ofile );
	fwrite( &offset, 1, sizeof( int ), ofile );
	fwrite( &dest, 1, sizeof( int ), ofile );
}

int Space::SetAttr( Attribute *a )
{
	if ( a->name == "dest" ) dest = a->value->num;
}

int Space::GetAttr( Array& a )
{
	Object::GetAttr( a );
	a.Add( "dest", new Data( dest ) );
	a.Add( "width", new Data( Width() ) );
}

void Space::Remove( SpaceObject *obj )
{
	for ( int oc = 0; oc < object.size(); oc++ )
	{
		if ( object[oc] == obj )
		{
			object.erase( object.begin() + oc );
			return;
		}
	}
}

typedef set<Space*> SSet;

Crossroad *FindCrossroadRec( Space *curs, int curPos, Space *dests, int destPos, int& path, SSet& sset )
{
	int bestPath = 20000;
	Crossroad *rv = 0;
	for ( int oc = 0; oc < curs->object.size(); oc++ )
	{
		if ( curs->object[oc]->type != "gate" ) continue;
		Crossroad *cr = (Crossroad*)( curs->object[oc] );
		Space *s = cr->conj->space;
		if ( !( sset.find( s ) == sset.end() ) ) continue;
		if ( s == dests ) 
		{
			path = abs( destPos - cr->conj->pos ) + abs( curPos - cr->pos );
			return cr;
		}
		sset.insert( curs );
		int newPath;
		Crossroad *cr1 = FindCrossroadRec( s, cr->conj->pos, dests, destPos, newPath, sset );
		sset.erase( curs );
		newPath += abs( curPos - cr->pos );
		if ( cr1 && newPath < bestPath ) 
		{
			bestPath = newPath;
			path = bestPath;
			rv = cr;
		}
	}
	path = bestPath;
	return rv;
}


Crossroad *Space::FindCrossroad( Space *dests, int pos, int srcPos )
{
	SSet sset;
	int path;
	return FindCrossroadRec( this, srcPos, dests, pos, path, sset );
}

void Space::DrawBack( Player *player, SDL_Surface *s )
{
	if ( player->dir )
	{
		if ( offset < player->pos - 80 && offset + 640 < Width() ) 
		{	
			offset += 20;
			if ( offset > player->pos - 80 ) offset = player->pos - 80;
			if ( offset > Width() - 640 ) offset = Width() - 640;
		}
		if ( offset > player->pos - 80 && offset > 0 ) 
		{	
			offset -= 20;
			if ( offset < player->pos - 80 ) offset = player->pos - 80;
			if ( offset < 0 ) offset = 0;
		}
	}
	else
	{
		if ( offset < player->pos - 500 && offset + 640 < Width() ) 
		{	
			offset += 20;
			if ( offset > player->pos - 500 ) offset = player->pos - 500;
			if ( offset > Width() - 640 ) offset = Width() - 640;
		}
		if ( offset > player->pos - 500 && offset > 0 ) 
		{	
			offset -= 20;
			if ( offset < player->pos - 500 ) offset = player->pos - 500;
			if ( offset < 0 ) offset = 0;
		}
	}
	SDL_Rect srcrect;
	srcrect.x = offset;
	srcrect.y = 0;
	srcrect.w = 640;
	srcrect.h = 480;
	SDL_Rect destrect;
	destrect.x = 0;
	destrect.y = 0;
	destrect.w = 640;
	destrect.h = 480;
	
	SDL_BlitSurface( surface, &srcrect, s, &destrect );
}

void Space::DrawObj( SDL_Surface *s )
{
	for ( int oc = 0; oc < object.size(); oc++ )
	{
		if ( !object[oc]->sprite ) continue;
		SDL_Rect rect;
		rect.x = object[oc]->pos - offset + object[oc]->sprite->x + object[oc]->clipLeft;
		rect.y = object[oc]->height + object[oc]->sprite->y - object[oc]->sprite->surface->h;
		rect.w = object[oc]->sprite->surface->w - object[oc]->clipLeft - object[oc]->clipRight;
		rect.h = object[oc]->sprite->surface->h;
		SDL_Rect srcRect;
		srcRect.x = object[oc]->clipLeft;
		srcRect.y = 0;
		srcRect.w = rect.w;
		srcRect.h = rect.h;

		SDL_BlitSurface( object[oc]->sprite->surface, &srcRect, s, &rect );
	}
 
}

void Space::ManagePlayer( Player *player, World *world )
{
    cursNum = 0;
 	for ( int oc = 0; oc < object.size(); oc++ )
 	{
 		if ( object[oc]->sel )
 		{
    		if ( match( screen, object[oc]->sprite->surface, 
    			object[oc]->pos + object[oc]->sprite->x - offset,
    			object[oc]->height + object[oc]->sprite->y - object[oc]->sprite->surface->h,
    			cursX,
    			cursY ) ) cursNum = 2;
    	}
 		if ( object[oc]->type == "gate" )
 		{
 			Crossroad *cr = (Crossroad*)( object[oc] );
 			if ( cr->pos - offset < cursX && cr->pos + cr->width - offset > cursX
 				&& cr->top < cursY && cr->top + cr->height > cursY )
 			{
				cursNum = 1;
				break;
 			}
 		}
 	}
	if ( button )
	{
		dest = cursX + offset;
		button = false;
		for ( int oc = 0; oc < object.size(); oc++ )
		{
			//if ( object[oc] == world->player ) continue;
			if ( object[oc]->type == "gate" )
			{
				Crossroad *cr = (Crossroad*)( object[oc] );
				if ( cr->pos - offset < cursX && cr->pos + cr->width - offset > cursX
					&& cr->top < cursY && cr->top + cr->height > cursY )
				{
					world->current = cr;
					return;
				}
			}
			else
			{
				if ( !object[oc]->sel ) continue;
    			if ( !match( screen, object[oc]->sprite->surface, 
    				object[oc]->pos + object[oc]->sprite->x - offset,
    				object[oc]->height + object[oc]->sprite->y - object[oc]->sprite->surface->h,
    				cursX,
    				cursY ) ) continue;
    			world->current = object[oc];
    			return;
    		}
		}
		world->current = 0;
	}
}

void Substitute( SDL_Surface *s1, SDL_Surface *s2 )
{
	const int rsize = 20;
	const int rnum = 640 / rsize;
	const int rstep = 4;
	const int delay = 30;
	for ( int rc = 0; rc < rsize / rstep; rc++ )
	{
		for ( int oc = 0; oc < rnum; oc++ )
		{
			SDL_Rect r1, r2;
			r1.y = r2.y = 0;
			r1.h = r2.h = 480;
			r2.x = oc * rsize;
			r2.w = rc * rstep;
			r1.x = r2.x + r2.w;
			r1.w = rsize - r2.w;
			SDL_BlitSurface( s1, &r1, screen, &r1 );
			SDL_BlitSurface( s2, &r2, screen, &r2 );
		}
       	SDL_Flip( screen );
       	SDL_Delay( delay );
    }
}

void UpdateRef( World *w )
{
	for ( int oc = 0; oc < w->object.size(); oc++ )
	{
		if ( w->object[oc]->type == "object" )
		{
			SpaceObject *o1 = ((SpaceObject*)(w->object[oc]));
			if ( !o1->ref.size() ) continue;
  			for ( int occ = 0; occ < w->object.size(); occ++ )
  			{
  				if ( w->object[occ]->name == o1->ref )
  				{
  					SpaceObject *o2 = ((SpaceObject*)w->object[occ]);
  					Data d;
  					d.type = dNumber;
  					d.num = o2->pos;
  					Attribute a;
  					a.name = "realpos";
  					a.value = &d;
  					o1->SetAttr( &a );
  				}
			}
		}
	}
}
