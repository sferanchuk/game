
//#define _SYS_UNISTD_H
//#include <windows.h>
//#include <winsock.h>

#ifndef WIN32
#define __LINUX__
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <SDL/SDL_thread.h>
#include <SDL/SDL_syswm.h>

#include "g15.h"
#include "res.h"
#include "../wxsrc/ccom.h"

#include "cursors.h"

SDL_Surface *screen;
//SDL_Cursor *cursor[3];
int cursX, cursY;
bool button;
int cursNum = 0;
bool reboot = false;
extern int line;
//HINSTANCE NEAR hModule;  
int extCommand = 0;
static World *theWorld;
int myFlag = 0;

SDL_Surface *SDL_LoadTIFF( const char *filename, bool back = false, bool mirror = false );
SDL_Surface *SDL_LoadJPEG( const char *filename );
void Substitute( SDL_Surface *s1, SDL_Surface *s2 );
Token *LoadScript();
int RunScript( World *world, Stack& stack );
void LoadPhases( Person* person, const char *name );
int Find( Array &ar, const string& field, Data& d );
Object *FindObject( World *world, const string& name );
int RunTarget( World *w, Person *p );
void UpdateRef( World *w );
int RunTK();
int TKStep();

void error( const char *msg )
{
	char buf[80];
	fprintf( stderr, "%s %d", msg, line );
	
	//MessageBox( 0, buf, "g15", MB_OK );
	exit( 0 );
}

SDL_Surface *loadSurface( const string& filename, bool back, bool mirror )
{
	SDL_Surface *surface;
	if ( filename.substr( filename.size() - 3, 3 ) == "jpg" )
	{
		surface = SDL_LoadJPEG( ("img/"+filename).c_str() );
	}
	else
	{
    	surface = SDL_LoadTIFF( ("img/"+filename).c_str(), back, mirror );
    }
    if ( !surface ) return 0;
	SDL_Surface *rv = SDL_DisplayFormat( surface );
	SDL_FreeSurface( surface );
	return rv;
}

void Array::Add( const string& n, Data *d )
{
   	for ( int ac = 0; ac < data.size(); ac++ )
   	{
   		if ( data[ac].name == n )
   		{
   			delete data[ac].value;
   			data[ac].value = d;
   			return;
   		}
   	}
	data.resize( data.size() + 1 );
	data.back().name = n;
	data.back().value = d;
}

Array::~Array()
{
	if ( del ) 
		for ( int dc = 0; dc < data.size(); dc++ ) 
			delete data[dc].value;
}

Array::Array( const Array& a )
{
	data.resize( a.data.size() );
	for ( int ac = 0; ac < a.data.size(); ac++ )
	{
		data[ac].name = a.data[ac].name;
		data[ac].value = new Data( *( a.data[ac].value ) );
	}
}

void Array::operator=( const Array& a )
{
	data.resize( a.data.size() );
	for ( int ac = 0; ac < a.data.size(); ac++ )
	{
		data[ac].name = a.data[ac].name;
		data[ac].value = new Data( *( a.data[ac].value ) );
	}
}	

int Object::Load( FILE *ifile, World *world )
{
	if ( !ReadString( name, ifile ) ) return 0;
	if ( !array.Load( ifile ) ) return 0;
	return 1;
}

int Object::Save( FILE *ofile )
{
	SaveString( name, ofile );
	array.Save( ofile );
}

int Object::SetAttr( Attribute *a )
{
   	array.Add( a->name, new Data( *(a->value) ) );
}

int Object::GetAttr( Array& a )
{
	for ( int ac = 0; ac < array.data.size(); ac++ )
	{
		a.Add( array.data[ac].name, new Data( *(array.data[ac].value) ) );
	}
	a.Add( "name", new Data( name ) );
	a.Add( "type", new Data( type ) );
}

int SpaceObject::Load( FILE *ifile, World *world )
{
	if ( !Object::Load( ifile, world ) ) return 0;
	fread( &pos, 1, sizeof( int ), ifile );
	fread( &height, 1, sizeof( int ), ifile );
	fread( &sel, 1, sizeof( int ), ifile );
	fread( &nphases, 1, sizeof( int ), ifile );
	fread( &phase, 1, sizeof( int ), ifile );
	fread( &clipLeft, 1, sizeof( int ), ifile );
	fread( &clipRight, 1, sizeof( int ), ifile );
	fread( &realpos, 1, sizeof( int ), ifile );
	if ( !ReadString( file, ifile ) ) return 0;
	if ( !ReadString( ref, ifile ) ) return 0;
	if ( file.size() ) sprite = new Sprite( loadSurface( file, false, false ) );
	string sname;
	if ( !ReadString( sname, ifile ) ) return 0;
	Space *s = FindSpace( world, sname );
	if ( !s ) return 0;
	space = s;
	s->object.push_back( this );
	return 1;
}

int SpaceObject::Save( FILE *ofile )
{
    Object::Save( ofile );
    fwrite( &pos, 1, sizeof( int ), ofile );
    fwrite( &height, 1, sizeof( int ), ofile );
    fwrite( &sel, 1, sizeof( int ), ofile );
    fwrite( &nphases, 1, sizeof( int ), ofile );
    fwrite( &phase, 1, sizeof( int ), ofile );
    fwrite( &clipLeft, 1, sizeof( int ), ofile );
    fwrite( &clipRight, 1, sizeof( int ), ofile );
    fwrite( &realpos, 1, sizeof( int ), ofile );
    SaveString( file, ofile );
    SaveString( ref, ofile );
    SaveString( space->name, ofile );
}

int SpaceObject::SetAttr( Attribute *a )
{
	Object::SetAttr( a );
	if ( a->name == "pos" ) pos = a->value->num;
	if ( a->name == "height" ) height = a->value->num;
	if ( a->name == "sel" ) sel = a->value->num;
	if ( a->name == "nphases" ) nphases = a->value->num;
	if ( a->name == "phase" ) 
	{
		phase = a->value->num;
		if ( nphases > 0 )
		{
			clipLeft = Width() * phase / nphases;
			clipRight = Width() * ( nphases - phase - 1 ) / nphases;
			pos = realpos - clipLeft;
		}
	}
	if ( a->name == "realpos" ) 
	{
		realpos = a->value->num;
		pos = realpos - clipLeft;
	}
	if ( a->name == "ref" )
	{
		ref = a->value->str;
	}
}

int SpaceObject::GetAttr( Array& a )
{
	Object::GetAttr( a );
	a.Add( "pos", new Data( pos ) );
	a.Add( "height", new Data( height ) );
	a.Add( "sel", new Data( sel ) );
	a.Add( "nphases", new Data( nphases ) );
	a.Add( "phase", new Data( phase ) );
	a.Add( "realpos", new Data( realpos ) );
	Array s;
	space->GetAttr( s );
	a.Add( "space", new Data( s ) );
	a.Add( "width", new Data( Width() ) );
}

SpaceObject::~SpaceObject()
{
	if ( file.size() ) delete sprite;
}

/*
Status::Status( World *w )
{
	owner = w;
}

void Status::Add( string name )
{
	item.resize( item.size() + 1 );
	item.back().name = name;
	//item.back().surface = loadSurface( file.c_str(), false, false );
}

void Status::Draw()
{
	return;
	if ( !owner->player ) return;
	int x = 600;
	int y = 20;
	for ( int ic = 0; ic < item.size(); ic++ )
	{
		Data d;
		if ( !Find( owner->player->array, item[ic].name, d ) ) continue;
		if ( d.type != dNumber ) continue;
		for ( int bc = 0; bc < d.num; bc++ )
    	{
       		SDL_Rect rect;
    		x = rect.x = x - item[ic].surface->w;
    		rect.y = y;
    		rect.w = item[ic].surface->w;
    		rect.h = item[ic].surface->h;
    		SDL_Rect srcRect;
    		srcRect.x = 0;
    		srcRect.y = 0;
    		srcRect.w = rect.w;
    		srcRect.h = rect.h;

    		SDL_BlitSurface( item[ic].surface, &srcRect, screen, &rect );
    	}
    }
}

Status::~Status()
{
	return;
	for ( int ic = 0; ic < item.size(); ic++ )
	{
		SDL_FreeSurface( item[ic].surface );
	}
}
*/

int World::init()
{
/*
	current = 0;
	player = new Player();
	player->pos = 100;
	player->height = 450;
	player->w = 50;
	player->pc = 0;
	player->dir = true;
	player->name = "player";
	player->phases = "player";
	LoadPhases( player, "player" );
	object.push_back( player );
*/
	script = LoadScript();
	globals.type = dArray;

	for ( int sc = 0; sc < script->list.size(); sc++ )
	{
		if ( script->list[sc]->str == "start" )
		{
			Stack *stack = new Stack;
			stack->vars.AddGlobals( &globals );
			stack->push( sPos, script->list[sc] );
			sample.push_back( stack );
			//RunScript( this, stack );
		}
		/*
		else
		{
			Stack *stack = new Stack;
			stack->push( sPos, script->list[sc] );
			stack->active = 0;
			stack->name = script->list[sc]->str;
		}
		*/
	}
/*	
	player->space = space[0];
	space[0]->object.push_back( player );
	reply = -1;
*/
	delay = 400;
	ltc = 0;
	if ( !LoadMap( map ) ) exit( 1 );
	map.mode = 0;
	//map.player->x = 5;
	//map.player->y = 5;
}

static void wStep( World *w )
{
	w->cltc = w->ltc = SDL_GetTicks();
	MoveObjects( w->map );
	w->execute();
	DrawMap( w->map, screen );

	SDL_Flip( screen );
}
	
static void wMove( World *w, int dir )
{
	wStep( w );
	TryToMove( w->map, dir );
}
 
int World::play()
{ 
	SDL_Event event;
	int tc;
	//button = false;
	bool movie = false;
	bool done = false;
	static Space *prevSpace = 0;

    while ( SDL_PollEvent( &event ) )
	{
		if  ( reboot )
		{
			reboot = false;
			return 0;
		}
		if ( event.type == SDL_MOUSEMOTION )
		{
			cursX = event.button.x;
			cursY = event.button.y;
			break;
		}
		if ( event.type == SDL_MOUSEBUTTONDOWN )
		{
			cursX = event.button.x;
			cursY = event.button.y;
			button = true;
			break;
		}
		if ( event.type == SDL_KEYDOWN )
		{
			switch ( event.key.keysym.sym )
			{
				case SDLK_UP:
				case SDLK_w:
					wMove( this, mUp );
					break;

				case SDLK_DOWN:
				case SDLK_s:
					wMove( this, mDown );
					break;

				case SDLK_RIGHT:
				case SDLK_d:
					wMove( this, mRight );
					break;

				case SDLK_LEFT:
				case SDLK_a:
					wMove( this, mLeft );
					break;

				case SDLK_SPACE:
					{
						map.mode = 1 - map.mode;
						myFlag = 1 - myFlag;
					}
					break;
			
				case SDLK_k:
					{
						char buf[20];
						sprintf( buf, "w %d %d %d %d ", 
							FindWay( map, map.player->x - 2, map.player->y, map.player->x, map.player->y ),
							FindWay( map, map.player->x, map.player->y - 2, map.player->x, map.player->y ),
							FindWay( map, map.player->x + 2, map.player->y, map.player->x, map.player->y ),
							FindWay( map, map.player->x, map.player->y + 2, map.player->x, map.player->y )
							);
						/*
						modFlag = 20;
						SDL_LockMutex( modMutex );
						//Tcl_MutexLock( &tclMutex );
						strcpy( messageBuf, buf );
						SDL_UnlockMutex( modMutex );
						//Tcl_MutexUnlock( &tclMutex );
						*/
						PrintMessage( buf );
					}
					break;
			}
		}
	}
		
	if ( event.type == SDL_QUIT )
	{
//				DestroyWindow(hwnd);
		return -1;
	}
	
	tc = SDL_GetTicks();
	if ( tc - ltc > delay )
	{
		wStep( this );
		//map.player->dir = mStay;
		map.player->moving = false;
	}
	if ( tc - cltc > delay / 4 )
	{
		cltc = tc;
		int cycle = ( cltc - ltc ) * 4 / delay;
		if ( map.mode == 1 && cycle > 0  )
		{
			DrawProj( map, screen, cycle );
			SDL_Flip( screen );
		}
	}
	return 0;
}

int World::execute()
{
	
	for ( int sc = 0; sc < sample.size(); )
	{
		//if ( sample[sc]->active )
		//{
		int rv = RunScript( this, *sample[sc] );
		if ( rv == 1 ) 
		{
			sample[sc]->vars.DetachGlobals();
			delete sample[sc];
			sample.erase( sample.begin() + sc );
		}
		else sc++;
	}
	/*
	for ( int oc = 0; oc < object.size(); oc++ )
	{
		if ( object[oc]->type == "person" )
		{
			int rv = RunTarget( this, (Person*)(object[oc]) );
		}
	}
	UpdateRef( this );
	if ( player->free )
		player->space->ManagePlayer( player, this );
	*/
}

int World::Save( FILE *ofile )
{
	/*
	int size = space.size();
	fwrite( &size, 1, sizeof( int ), ofile );
	for ( int sc = 0; sc < space.size(); sc++ )
	{
		space[sc]->Save( ofile );
	}
	size = object.size();
	fwrite( &size, 1, sizeof( int ), ofile );
	for ( int oc = 0; oc < object.size(); oc++ )
	{
		SaveString( object[oc]->type, ofile );
		object[oc]->Save( ofile );
	}
	SaveToken( script, ofile );
	size = sample.size();
	fwrite( &size, 1, sizeof( int ), ofile );
	for ( int sc = 0; sc < sample.size(); sc++ )
	{
		sample[sc]->Save( ofile );
	}
	size = ( current == 0 ) ? 0 : 1;
	fwrite( &size, 1, sizeof( int ), ofile );
	if ( size ) SaveString( current->name, ofile );
	fwrite( &delay, 1, sizeof( int ), ofile );
	return 1;
	*/
}

int World::Load( FILE *ifile )
{
	/*
	int size;
	fread( &size, 1, sizeof( int ), ifile );
	for ( int sc = 0; sc < size; sc++ )
	{
		Space *s = new Space;
		if ( !s->Load( ifile, this ) ) return 0;
		space.push_back( s );
	}
	fread( &size, 1, sizeof( int ), ifile );
	for ( int oc = 0; oc < size; oc++ )
	{
		string type;
		ReadString( type, ifile );
		Object *o;
		if ( type == "object" )	o = new SpaceObject;
		else if ( type == "person" ) o = new Person;
		else if ( type == "phantom" ) o = new Phantom;
		else if ( type == "gate" ) o = new Crossroad;
		else if ( type == "player" ) 
		{
			o = new Player;
			player = (Player*)o;
		}
		o->Load( ifile, this );
		object.push_back( o );
	}
	script = new Token;
	LoadToken( script, ifile );
	fread( &size, 1, sizeof( int ), ifile );
	for ( int sc = 0; sc < size; sc++ )
	{
		Stack *s = new Stack;
		s->Load( ifile, script );
		sample.push_back( s );
	}
	fread( &size, 1, sizeof( int ), ifile );
	if ( size ) 
	{
		string cname;
		ReadString( cname, ifile );
		current = FindObject( this, cname );
	}
	else current = 0;
	fread( &delay, 1, sizeof( int ), ifile );
	return 1;
	*/
}

World::~World()
{
	/*
	for ( int sc = 0; sc < space.size(); sc++ ) delete space[sc];
	for ( int oc = 0; oc < object.size(); oc++ ) delete object[oc];
	for ( int sc = 0; sc < sample.size(); sc++ ) delete sample[sc];
	delete script;
	*/
}

#define RV 0

int GraphicsMain( void *data )
{
	if ( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO ) < 0 ) 
	{
		printf( "%s\n", SDL_GetError() );
		return RV;
	}

	Uint32 videoflags = SDL_SWSURFACE | SDL_DOUBLEBUF;
	Uint8 videobpp = 24;
	screen = SDL_SetVideoMode( 640, 480, videobpp, videoflags );
	if ( !screen )
	{
		printf( "%s\n", SDL_GetError() );
		return RV;
	}
	SDL_WM_SetCaption( "G15", "" );
	SDL_SysWMinfo info;
	int posx = 20, posy = 20;
	
	SDL_VERSION(&info.version);
	if (SDL_GetWMInfo(&info) > 0 ) 
	{
#ifdef __LINUX__
		if (info.subsystem == SDL_SYSWM_X11) 
		{
    		XMoveWindow(info.info.x11.display, info.info.x11.wmwindow, posx, posy);
  		}
#else
		SetWindowPos( info.window, HWND_TOP, posx, posy, 0, 0, SWP_NOSIZE );
#endif
	}
	
	//SDL_ShowCursor( 0 );
	SDL_EnableKeyRepeat( 500, 30 );
	fd.modMutex = SDL_CreateMutex();
	
	theWorld = new World;
	if ( !theWorld->init() ) return RV;
	do
	{
		//if ( theWorld->execute() == -1 ) break;
		if ( theWorld->play() == -1 ) break;
	}
	while ( 1 );
	return RV;
}

	//delete theWorld;
#ifndef __LINUX__

int __stdcall WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
                     
/*
int __stdcall WinMain(void *hInstance,
            void *hPrevInstance,
            char *lpCmdLine,
            int       nCmdShow)
			*/
#else
static Tcl_ThreadId tclId;

int main()

#endif
{

    /*
	if ( Tcl_CreateThread( &tclId, GraphicsMain, 0, TCL_THREAD_STACK_DEFAULT, TCL_THREAD_NOFLAGS ) == TCL_ERROR )
	{
		fprintf( stderr, "error creating thread\n" );
		exit( 1 );
	}
	*/
	SDL_CreateThread( GraphicsMain, 0 );
	RunTK();
	
	return 0;
}
