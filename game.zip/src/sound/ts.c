
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "SDL/SDL.h"

#include "mpg123_sdlsound.h"
#include "mpglib_sdlsound.h"

typedef struct 
{
	FILE *ifile;
	Uint8 *buffer;
	Uint32 bsize;
	Uint32 bpos;
	SDL_AudioSpec spec;
	struct mpstr mp;

	Uint8 *inbuf;
	Uint32 inbsize;
	Uint8 *outbuf;
	Uint32 outbsize;
	Uint32 outpos;
	Uint32 outleft;
	Uint32 bw;
	int in_use;
	int eflag;
} Userdata;


#define Maxsound 5

static Userdata sounds[ Maxsound ];

static int mp3_open( Userdata *ud)
{
    memset(&(ud->mp), '\0', sizeof (ud->mp));
    InitMP3(&(ud->mp));
    fread( ud->inbuf, 1, ud->inbsize, ud->ifile );
    if (decodeMP3(&(ud->mp), ud->inbuf, ud->inbsize,
                    ud->outbuf, ud->outbsize,
                    &(ud->outleft)) == MP3_ERR)
    {
    	printf( "error starting reading mp3\n" );
    	exit( 1 );
    }
    ud->spec.freq = mpglib_freqs[ud->mp.fr.sampling_frequency];
    ud->spec.channels = ud->mp.fr.stereo;
    ud->spec.format = AUDIO_S16SYS;
    ud->outpos = 0;

    return(1);
} 

static int mp3_read( Userdata *ud )
{
    int rc;
    Uint32 cpysize;
    
    if ( ud->eflag ) return;

    while ( ud->bw < ud->bsize )
    {
        if ( ud->outleft > 0)
        {
            cpysize = ud->bsize - ud->bw;
            if ( cpysize > ud->outleft )      cpysize = ud->outleft;
            memcpy( ud->buffer + ud->bw, ud->outbuf + ud->outpos, cpysize );
            ud->bw += cpysize;
            //outpos += cpysize;
            ud->outleft -= cpysize;
            continue;
        } 

        ud->outpos = 0;
        rc = decodeMP3( &(ud->mp), NULL, 0, ud->outbuf, ud->outbsize, &(ud->outleft) );
        if (rc == MP3_ERR)
        {
        	printf( "error reading mp3" );
        	exit( 1 );
        } 

        else if (rc == MP3_NEED_MORE)
        {
		    rc = fread( ud->inbuf, 1, ud->inbsize, ud->ifile );
            if (rc < ud->inbsize) 
            {
                ud->eflag = 1;
            	return ud->bw;
            }
            rc = decodeMP3(&(ud->mp), ud->inbuf, rc, ud->outbuf, ud->outbsize, &(ud->outleft));
            if (rc == MP3_ERR)
            {
	        	printf( "error reading mp3" );
    	    	exit( 1 );
        	} 
        }
    } 
    return ud->bw;
} 

void StopChannel( Userdata *ud )
{
	free( ud->inbuf );
	free( ud->outbuf );
	fclose( ud->ifile );
	ExitMP3( &(ud->mp) );
	free( ud->buffer );
	ud->in_use = 0;
	ud->eflag = 0;
}

static void audio_callback(void *userdata, Uint8 *stream, int len)
{
    int i;
    Userdata *ud;

    for ( i = 0; i < Maxsound; i++ )
    {
		Userdata *ud = sounds + i;
    	if ( !ud->in_use ) continue;
    	int cpysize = len;
    	if ( cpysize > ud->bw ) 
    	{
    	    cpysize = ud->bw;
    		SDL_MixAudio( stream, ud->buffer, cpysize, SDL_MIX_MAXVOLUME );
    		StopChannel( ud );
    		break;
    	}
    	SDL_MixAudio( stream, ud->buffer, cpysize, SDL_MIX_MAXVOLUME );
    	memmove( ud->buffer, ud->buffer + cpysize, ud->bw - cpysize );
    	ud->bw -= cpysize;
    	mp3_read( ud );
    }
} 

static int opened = 0;

int PlayMP3( const char *fname )
{
	FILE *ifile;
	int curUD;
	Userdata *ud;

	for ( curUD = 0; curUD < Maxsound && sounds[curUD].in_use; curUD++ );
	if ( curUD == Maxsound ) return 0;
	ud = sounds + curUD;
	ud->ifile = fopen( fname, "rb" );
	if ( !ud->ifile ) return 0;

	ud->inbsize = 16384;
	ud->outbsize = 8192;
	ud->inbuf = malloc( ud->inbsize );
	ud->outbuf = malloc( ud->outbsize );

	ud->spec.samples = 8192;
	ud->bsize = 65536;
	ud->buffer = malloc( ud->bsize + ud->outbsize );
	ud->bpos = 0;
	ud->bw = 0;
	mp3_open( ud );
	mp3_read( ud );
	ud->bpos = 0;

	ud->spec.callback = audio_callback;
	ud->spec.userdata = ud;
	ud->in_use = 1;

	if ( !opened )
	{
		if ( SDL_OpenAudio(&(ud->spec), NULL) < 0 ) {
			fprintf(stderr, "Couldn't open audio: %s\n", SDL_GetError());
			exit(2);
		}
		SDL_PauseAudio(0);
		opened = 1;
	}
	return 1;
}

int Silence()
{
	int curUD;

	SDL_CloseAudio();
	for ( curUD = 0; curUD < Maxsound; curUD++ )
	{
		if ( sounds[ curUD ].in_use )
		{
			StopChannel( sounds + curUD );
		}
	}
	opened = 0;
	return 1;
}

/*
int main(int argc, char **argv)
{
    if ( SDL_Init(SDL_INIT_AUDIO) == -1 )
    {
        fprintf(stderr, "SDL_Init() failed!\n"
                        "  reason: [%s].\n", SDL_GetError());
        return(42);
    } 
    ..
	if ( SDL_LoadWAV( "sample.wav",
			&spec, &audioBuf, &audioLen) == NULL ) {
		fprintf(stderr, "Couldn't load %s: %s\n",
						argv[1], SDL_GetError());
		exit(1);
	}
	..
	PlayMP3( "dog.mp3" ); 

	SDL_Delay(40000);

	SDL_CloseAudio();
    SDL_Quit();
    return(0);
} 
*/

