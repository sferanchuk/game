
#include <SDL/SDL.h>

//extern FILE *tfile;

int match( SDL_Surface *screen, SDL_Surface *image, int xpos, int ypos, int x, int y )
{
	if ( x < xpos || x >= xpos + image->w ) return 0;
	if ( y < ypos || y >= ypos + image->h ) return 0;
	//SDL_LockSurface( screen );
	SDL_LockSurface( image );

	int depth = image->format->BytesPerPixel;

//	fprintf( tfile, "%u %u %u %u\n", image->pitch, image->w, screen->pitch, screen->w );
/*
	for ( int hc = 0; hc < image->h; hc++ )
	{
		for ( int wc = 0; wc < image->pitch; wc++ )
		{
			fprintf( tfile, "%2.2x", *( (Uint8*)image->pixels + hc * image->pitch + wc ) );
		}	
		fprintf( tfile, "\n" );
	}
	
	
	for ( int dc = 0; dc < depth; dc++ )
	{
		
		fprintf( tfile, "%u %u %u %u %u, %x %x\n", x, y, x - xpos, y - ypos, depth,
				 * ( (Uint8*)( screen->pixels ) 
			+ y * screen->pitch + x * depth + dc ),
				* ( (Uint8*)( image->pixels ) 
			+ ( y - ypos ) * image->pitch + ( x - xpos ) * depth + dc ) ); 
	}
*/
	Uint8 r1, g1, b1, r2, g2, b2;
	/*
	SDL_GetRGB( *( (Uint32*)( (Uint8*)(screen->pixels) 
	  + y * screen->pitch + x * depth 
	   ) ), screen->format, &r1, &g1, &b1 );			
	*/
	SDL_GetRGB( *( (Uint32*)( (Uint8*)(image->pixels) 
	  ) ), image->format, &r1, &g1, &b1 );			
	SDL_GetRGB( *( (Uint32*)( (Uint8*)(image->pixels) 
	  + ( y - ypos ) * image->pitch + ( x - xpos ) * depth 
	  ) ), image->format, &r2, &g2, &b2 );			
//	fprintf( tfile, "%u %u %u %u: %x %x %x %x %x %x\n", xpos, x, ypos, y, r1, g1, b1, r2, g2, b2 );


	//SDL_UnlockSurface( screen );
	SDL_UnlockSurface( image );
	return r1 != r2 || g1 != g2 || b1 != b2;
	return 1;
}

