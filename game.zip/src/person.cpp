
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <string>
#include <vector>

using namespace std;

#include <SDL/SDL.h>

#include "g15.h"

SDL_Surface *loadSurface( const string& filename, bool back = false, bool mirror = false );
void LoadPhases( Person* person, const char *name );
void RegisterAttr( string code, int count ) {};
Object *FindObject( World *world, const string& name );
Space *FindSpace( World *world, const string& name );
int RunScript( World *world, Stack& stack );
void PrintMessage( const char *buf );
//int Find( Array &ar, const string& field, Data& d );
int FindNumber( Array& ar, const string& field );


int Person::Load( FILE *ifile, World *world )
{
	if ( !SpaceObject::Load( ifile, world ) ) return 0;
    if ( !ReadString( phases, ifile ) ) return 0;
    fread( &w, 1, sizeof( int ), ifile );
    fread( &pc, 1, sizeof( int ), ifile );
    fread( &dir, 1, sizeof( bool ), ifile );
   	LoadPhases( this, phases.c_str() );
   	return 1;

}

int Person::Save( FILE *ofile )
{
	SpaceObject::Save( ofile );
	SaveString( phases, ofile );
	fwrite( &w, 1, sizeof( int ), ofile );
	fwrite( &pc, 1, sizeof( int ), ofile );
	fwrite( &dir, 1, sizeof( bool ), ofile );
}

int Person::SetAttr( Attribute *a )
{
	SpaceObject::SetAttr( a );
	if ( a->name == "dir" ) dir = a->value->num;
	if ( a->name == "territory" ) dir = a->value->num;
}

int Person::GetAttr( Array& a )
{
	SpaceObject::GetAttr( a );
	a.Add( "dir", new Data( dir ) );
	a.Add( "width", new Data( w ) );
	a.Add( "territory", new Data( territory ) );
}

const int stepsize = 10;


int GetDirection( Direction& d, Person *p, SpaceObject *dest )
{
	if ( p->space == dest->space )
	{
		d.gate = 0;
		d.pos = dest->pos;
		if ( p->pos == dest->pos ) 
		{
			return 0;
		}
		return 1;
	}
	Crossroad *cr = p->space->FindCrossroad( dest->space, dest->pos, p->pos );
	d.gate = cr;
	d.pos = cr->pos;
	if ( p->pos < cr->pos ) 
	{
		if ( cr->pos - p->pos < stepsize ) return 1;
	}
	else 
	{
		if ( p->pos - cr->pos < stepsize ) return 1;
	}
	d.gate = 0;
	return 1;
}

void AddCell( vector<Cell>& cell, Rule *r, Direction *d, int score, bool wait = false )
{
   	int cec;
   	for ( cec = 0; cec < cell.size(); cec++ )
   	{
   		if ( r != 0 && cell[cec].r == r 
   			//|| 	d != 0 && ( d->gate != 0 && cell[cec].d.gate == d->gate || cell[cec].d.d == d->d ) 
   			|| wait && cell[cec].wait
   			)
   		{
   			cell[cec].score += score;
   			break;
   		}
   	}
   	if ( cec == cell.size() )
   	{
		Cell c;
		c.r = r;
		if ( d ) c.d = *d;
		c.score = score;
		c.wait = wait;
		cell.push_back( c );
	}
}

int DefTargetRec( World *w, Person *p, vector<Cell>& cell, vector<Aim>& aim, int level )
{
	int rv = 0;
	int ac;
	for ( ac = 0; ac < aim.size(); ac++ )
	{
		bool cmpl = false;
		for ( int pc = 0; pc < p->state.size(); pc++ )
		{
			if ( p->state[pc] == aim[ac].predicate )
			{
				cmpl = true;
				break;
			}
		}
		if ( cmpl ) continue;
		rv = 1;
		int rc;
		for ( rc = 0; rc < p->rule.size(); rc++ )
		{
			if ( !(p->rule[rc]->result == aim[ac].predicate) ) continue;
    		int weight = aim[ac].weight - p->rule[rc]->weight;
       		Token *cond = p->rule[rc]->cond;
       		int c_c = level;
       		for ( int cc = 0; cc < cond->list.size(); cc++ )
       		{
       			string function = cond->list[cc]->str;
       			if ( function == "Cond" || function == "IncCond" )
       			{
       				Predicate pred;
       				if ( weight <= 0 ) 
       				{
       					c_c = -1;
       					break;
       				}
       				pred.name = cond->list[cc]->list[0]->str;
       				vector< Aim > aim_n;// = aim;
       				//aim_n.erase( aim_n.begin() + ac );
       				bool afind = false;
       				/*
       				for ( int acc = 0; acc < aim_n.size(); acc++ )
       				{
       					if ( aim_n[acc].predicate == pred )
       					{
       						if ( aim_n[acc].weight > weight ) aim_n[acc].weight = weight;
       						afind = true;
       					}
       				}
       				*/
       				if ( !afind )
       				{
       					Aim a;
       					a.predicate = pred;
       					a.weight = weight;
       					aim_n.push_back( a );
       				}
    	   			int res = DefTargetRec( w, p, cell, aim_n, c_c );
       				if ( res == -1 )
       				{
       					c_c = -1;
       					break;
       				}
       				else if ( res == 1 )
       				{
       				 	c_c = 1;
       				}
       			}
       			else if ( function == "Go" )
       			{
       				if ( c_c != 0 ) continue;
       				Direction d;
       				Token *arg = cond->list[cc];
       				SpaceObject *o;
    				SpaceObject so;
       				if ( arg->list.size() == 1 )
       				{
       				 	o = (SpaceObject*)FindObject( w, arg->list[0]->str );
       				}
       				else
       				{
       					so.pos = arg->list[1]->num;
       					so.space = FindSpace( w, arg->list[0]->str );
       					o = &so;
       				}
       				if ( GetDirection( d, p, o ) )
       				{
       					AddCell( cell, 0, &d, aim[ac].weight - p->rule[rc]->weight );
       					c_c = 1;
       				}
       			}
       			else if ( function == "Wait" )
       			{
       				if ( c_c == 0 ) 
       				{
       					AddCell( cell, 0, 0, weight, true );
       					c_c = 1;
       				}
       			}
       		}
       		if ( c_c == 0 )
     		{
       			AddCell( cell, p->rule[rc], 0, weight );
    		}
		}
   	}
   	return rv;
}

int RunTarget( World *w, Person *p )
{
	vector<Cell> cell;
	int res = DefTargetRec( w, p, cell, p->aim, 0 );
	if ( !cell.size() ) return 0;
	int maxw = 0;
	int bestc = -1;
	int maxgw = 0;
	int bestgc = -1;
	bool wflag = false;
	for ( int cc = 0; cc < cell.size(); cc++ )
	{
		if ( cell[cc].score > maxw && cell[cc].r )
		{
			maxw = cell[cc].score;
			bestc = cc;
		}
		if ( cell[cc].score > maxgw && !cell[cc].r )
		{
			maxgw = cell[cc].score;
			bestgc = cc;
		}
	}
	if ( bestc != -1 )
	{
		if ( bestgc != -1 )
		{
			if ( !cell[bestgc].wait && maxgw > maxw ) bestc = bestgc;
		}
	}
	else bestc = bestgc;

	Cell& bc = cell[bestc];
	if ( bc.wait );
	else if ( bc.r == 0 )
	{
		Space *destSpace;
		int destPos;
		if ( bc.d.gate )
		{
			if ( p->space == bc.d.gate->space )
			{
				destSpace = bc.d.gate->conj->space;
				destPos = bc.d.gate->conj->pos;
			}
		}
		else
		{
			destSpace = p->space;
			destPos = bc.d.pos;
		}
		p->Go( destSpace, destPos );
	}
	else
	{
		if ( p->curRule == bc.r && p->waitCnt < p->curRule->wait )
		{
			p->waitCnt++;
		}
		else if ( p->curRule != bc.r && bc.r->wait != 0 )
		{
			p->curRule = bc.r;
			p->waitCnt = 0;
		}
		else
		{
			p->curRule = bc.r;
			p->waitCnt = 0;
   			Stack stack;
   			stack.push( sPos, bc.r->action );
   			stack.active = 1;
   			w->curPerson = p;
   			RunScript( w, stack );
   			w->curPerson = 0;
   		}
   	}
   	return 1;
}


int Person::Go( Space *destSpace, int destPos )
{
	int dest = -1;
	Crossroad *cr = 0;

	if ( phantom )
	{
		bool toDel = false;
		if ( phantom->dir )
		{
			phantom->clipRight += stepsize;
			phantom->pos += stepsize;
			if ( phantom->clipRight > w ) toDel = true;
		}
		else
		{
			phantom->clipLeft += stepsize;
			phantom->pos -= stepsize;
			if ( phantom->clipLeft > w ) toDel = true;
		}
		if ( toDel )
		{
		    phantom->space->Remove( phantom );
    		delete phantom;
    		phantom = 0;
    	}
    }
    height = 450;
    if ( pos == destPos && ( destSpace == 0 || destSpace == space ) ) return 0;
	if ( destPos != -1 )
	{
		if ( destSpace && destSpace != space )
		{
			cr = space->FindCrossroad( destSpace, destPos, pos );
			dest = cr->pos;
		}
		else dest = destPos;
		if ( pos < dest ) dir = true;
		else dir = false;
	}
	if ( clipLeft > 0 ) clipLeft -= stepsize;
	if ( clipLeft < 0 ) clipLeft = 0;
	if ( clipRight > 0 ) clipRight -= stepsize;
	if ( clipRight < 0 ) clipRight = 0;
	if ( dir )
	{
		pc = ( pc + 1 ) % forwardPhase.size();
		sprite = forwardPhase[ pc ];
		pos += stepsize;
		if ( pos + Width() > space->Width() )
		{	
			pos = space->Width() - Width();
			return 0;
		}
		if ( dest != -1 && dest < pos ) 
		{
			pos = dest;
		}
	}
	else
	{
		
		pc = ( pc + 1 ) % backwardPhase.size();
		sprite = backwardPhase[ pc ];
		pos -= stepsize;
		if ( pos < 0 )
		{	
			pos = 0;
			return 0;
		}
		if ( dest != -1 && dest > pos ) 
		{
			pos = dest;
		}
	}
	if ( cr && pos >= dest && pos <= dest + cr->width )
	{
		if ( phantom )
		{
		    phantom->space->Remove( phantom );
    		delete phantom;
    	}
	    phantom = new Phantom( *this );
	    space->Remove( this );
   		phantom->space = space;
   		space->object.push_back( phantom );
   		space = cr->conj->space;
   		cr->conj->space->object.push_back( this );
   		pos = cr->conj->pos;
   		if ( type == "player" ) 
   		{
   			cr->conj->space->offset = min( max( pos - 200, 0 ), cr->conj->space->Width() - 640 );
   			cr->conj->space->dest = pos;
   		}
   		else
   		{
   		    // bug ??
   		    if ( destPos > pos ) clipLeft = w;
   		    else clipRight = w;
   		}
   		return 1;
   	}
   	else if ( pos ==  dest ) return 0;
   	else return 1;
	return -1;
}

void Person::ChangeTerritory( string name, int value )
{
//	territory += value;

	Array ar;
	GetAttr( ar );
	int cvalue = 0;
	Data d;
	if ( Find( ar, name, d ) ) cvalue = d.num;
	Attribute a;
	cvalue += value;
	a.name = name;
	Data dd;
	dd.type = dNumber;
	dd.num = cvalue;
	a.value = &dd;
	SetAttr( &a );
}

Person::~Person()
{
	sprite = 0;
	delete forwardStayPhase;
	delete backwardStayPhase;
	delete sittingPhase;
	delete layingPhase;
	for ( int pc = 0; pc < forwardPhase.size(); pc++ ) delete forwardPhase[pc];
	for ( int pc = 0; pc < backwardPhase.size(); pc++ ) delete backwardPhase[pc];
	delete phantom;
}

#ifndef F_OK
static int access( const char *fname, int flag )
{
	FILE *ifile = fopen( fname, "rb" );
	if ( ifile )
	{
		fclose( ifile );
		return 0;
	}
	return 1;
}
#endif

static bool ImageExists( string name )
{
	return access( ("img/" + name ).c_str(), 0 ) == 0;
}

void LoadPhases( Person* person, const char *name )
{
	char buf[100];
	sprintf( buf, "%s-0.tif", name );
	SDL_Surface *stay = 0;
	if ( ImageExists( buf ) )
	{
		stay = loadSurface( buf );
		person->forwardStayPhase = new Sprite( stay );
		person->backwardStayPhase = new Sprite( loadSurface( buf, false, true ) );
	}
	sprintf( buf, "%s-s.tif", name );
	if ( ImageExists( buf ) )
	{
		SDL_Surface *sit = loadSurface( buf );
		person->sittingPhase = new Sprite( sit );
	}
	else person->sittingPhase = 0;
	sprintf( buf, "%s-l.tif", name );
	if ( ImageExists( buf ) )
	{
		SDL_Surface *l = loadSurface( buf );
		person->layingPhase = new Sprite( l );
	}
	else person->layingPhase = 0;
	int cnt = 1;
	do
	{
		sprintf( buf, "%s-%d.tif", name, cnt );
		if ( !ImageExists( buf ) ) break;
		SDL_Surface *s = loadSurface( buf );
		if ( !stay )
		{
			stay = loadSurface( buf, false, false );
			person->forwardStayPhase = new Sprite( stay );
			person->backwardStayPhase = new Sprite( loadSurface( buf, false, true ) );
		}
		person->forwardPhase.push_back( new Sprite( s ) );
		person->backwardPhase.push_back( new Sprite( loadSurface( buf, false, true ) ) );
		cnt++;
	}
	while ( true );
	person->sprite = person->forwardStayPhase;
}

int Phantom::Load( FILE *ifile, World *world )
{
	if ( !Person::Load( ifile, world ) ) return 0;
   	return 1;

}

int Phantom::Save( FILE *ofile )
{
	Person::Save( ofile );
}

int Player::Load( FILE *ifile, World *world )
{
	if ( !Person::Load( ifile, world ) ) return 0;
	fread( &free, 1, sizeof( int ), ifile );
	fread( &bottle, 1, sizeof( int ), ifile );
	fread( &money, 1, sizeof( int ), ifile );
	fread( &alcohol, 1, sizeof( int ), ifile );
   	return 1;
}

int Player::Save( FILE *ofile )
{
	Person::Save( ofile );
	fwrite( &free, 1, sizeof( int ), ofile );
	fwrite( &bottle, 1, sizeof( int ), ofile );
	fwrite( &money, 1, sizeof( int ), ofile );
	fwrite( &alcohol, 1, sizeof( int ), ofile );
}

int Player::SetAttr( Attribute *a )
{
	Person::SetAttr( a );
	if ( a->name == "free" ) free = a->value->num;
	if ( a->name == "bottle" ) bottle = a->value->num;
	if ( a->name == "money" ) money = a->value->num;
	if ( a->name == "alcohol" ) alcohol = a->value->num;
	RegisterAttr( a->name, a->value->num );
}

int Player::GetAttr( Array& a )
{
	Person::GetAttr( a );
	a.Add( "free", new Data( free ) );
	a.Add( "bottle", new Data( bottle ) );
	a.Add( "money", new Data( money ) );
	a.Add( "alcohol", new Data( alcohol ) );
}

const int fwBorder = 2;
const int fwBig = 1000;

int FindWay( Map& m, int x1, int y1, int x2, int y2 )
{
	char dbuf[100];
	int sizex = abs( x1 - x2 ) + 2 * fwBorder + 1;
	int sizey = abs( y1 - y2 ) + 2 * fwBorder + 1;
	int lowerx = min( x1, x2 ) - fwBorder;
	int lowery = min( y1, y2 ) - fwBorder;
	bool *avail = new bool[ sizex * sizey ];
   	int *dyn = new int[ sizex * sizey ];
	for ( int xc = 0; xc < sizex; xc++ )
	{
		for ( int yc = 0; yc < sizey; yc++ )
		{
			int rx = xc + lowerx;
			int ry = yc + lowery;
			avail[ yc * sizex + xc ] = 
				( rx >= 0 
				&& rx < m.amap[0].size()
				&& ry >= 0
				&& ry < m.amap.size()
				&& m.amap[ry][rx] > 0 );
			dyn[ yc * sizex + xc ] = fwBig;
		}
    }
  	for ( MapObjectIter it = m.object.begin(); it != m.object.end(); it++ )
	{
		//if ( (*it).first == "player" ) continue;
		MapObject& mo = (*it);
		if ( !mo.type ) continue;
		for ( int xc = 0; xc < mo.type->w; xc++ )
		{
			for ( int yc = 0; yc < mo.type->h; yc++ )
			{
				int cx = mo.x + xc - lowerx;
				int cy = mo.y + yc - lowery;
				if ( cx < 0 || cx >= sizex || cy < 0 || cy >= sizey ) continue;
				if ( cx == x2 - lowerx && cy == y2 - lowery ) continue;
				avail[ cy * sizex + cx ] = false;
			}
		}
	}
   	int tx = x1 - lowerx;
   	int ty = y1 - lowery;
   	if ( avail[ ty * sizex + tx ] )	dyn[ ty * sizex + tx ] = 0;
   	else
   	{
   		if ( avail[ ( ty - 1 ) * sizex + tx ] ) dyn[ ( ty - 1 ) * sizex + tx ] = 0;
   		if ( avail[ ( ty + 1 ) * sizex + tx ] ) dyn[ ( ty + 1 ) * sizex + tx ] = 0;
   		if ( avail[ ty * sizex + tx + 1 ]     ) dyn[ ty * sizex + tx + 1 ]     = 0;
   		if ( avail[ ty * sizex + tx - 1 ]     ) dyn[ ty * sizex + tx - 1 ]     = 0;
   	}
   	
   	bool eflag = false;
   	while ( !eflag )
   	{
   		eflag = true;
   		for ( int xc = 0; xc < sizex; xc++ )
   		{
   			for ( int yc = 0; yc < sizey; yc++ )
   			{
   				if ( !avail[ yc * sizex + xc ] ) continue;
   				if ( dyn[ yc * sizex + xc ] != fwBig ) continue;
   				int left = ( xc > 0 ) ? dyn[ yc * sizex + xc - 1 ] : fwBig;
   				int top = ( yc > 0 ) ? dyn[ ( yc - 1 ) * sizex + xc ] : fwBig;
   				int right = ( xc < sizex - 1 ) ? dyn[ yc * sizex + xc + 1 ] : fwBig;
   				int bottom = ( yc < sizey - 1 ) ? dyn[ ( yc + 1 ) * sizex + xc ] : fwBig;
   				int value = min( min( left, top ), min( right, bottom ) );
   				if ( value != fwBig )
   				{
   					dyn[ yc * sizex + xc ] = value + 1;
   					eflag = false;

   					/*
   					char buf[100];
   					sprintf( buf, "(%d %d) %d ", xc, yc, value );
   					PrintMessage( buf );
   					*/
   				}
   			}
   		}
   	}
   	int px = x2 - lowerx;
   	int py = y2 - lowery;
   	int rv = -1;
	int left = dyn[ py * sizex + px - 1 ];
	int top = dyn[ ( py - 1 ) * sizex + px ];
	int right = dyn[ py * sizex + px + 1 ];
	int bottom = dyn[ ( py + 1 ) * sizex + px ];
	int value = min( min( left, top ), min( right, bottom ) );
	if ( value == fwBig ) rv = -1;
	else if ( dyn[ py * sizex + px ] == 0 ) rv = mStay;
	//else if ( value == 0 && !avail[ py * sizex + px ] ) rv = mStay;
	else if ( value == left ) rv = mLeft;
	else if ( value == top ) rv = mUp;
	else if ( value == right ) rv = mRight;
   	else if ( value == bottom ) rv = mDown;
   	delete avail;
   	delete dyn;
   	return rv;
}
   		 
int DoGo( Map& m, const string& person, Array& path, int point )
{
	MapObject *mo = 0;
	for ( MapObjectIter it = m.object.begin(); it != m.object.end(); it++ )
	{
		if ( (*it).name == person )
		{
			mo = &(*it);
			break;
		}
	}
	if ( !mo ) error( "Go: object not found" );
	int x2 = mo->x;
	int y2 = mo->y;
	if ( point < 0 || point > path.data.size() ) error( "Go: incorrect path point" );
	if ( point == 0 ) point++;
	Data rp = *(path.data[ point - 1 ].value);
	if ( rp.type != dArray ) error( "Go: incorrect path type" );
	int x1 = FindNumber( rp.array, "x" );
	int y1 = FindNumber( rp.array, "y" );
	int res = FindWay( m, x1, y1, x2, y2 );
	if ( res == -1 ) return point;
	mo->dir = res;
	mo->moving = ( res != mStay );
	if ( res == mStay ) return point - 1;
	/*
	if ( res == mUp ) (mo->y)--;
	else if ( res == mDown ) (mo->y)++;
	else if ( res == mLeft ) (mo->x)--;
	else if ( res == mRight ) (mo->x)++;
	*/
	return point;
}

