// from orig. wx code by Robert Roebling

#include <SDL/SDL.h>
#include "tiff.h"
#include "tiffio.h"


SDL_Surface *SDL_LoadTIFF( const char *fname, bool back, bool mirror )
{
	TIFF *tiff = TIFFOpen( fname, "rb+" );
	if ( !tiff ) return 0;
    uint32 w, h;
    uint32 npixels;
    uint32 *raster;

    TIFFGetField( tiff, TIFFTAG_IMAGEWIDTH, &w );
    TIFFGetField( tiff, TIFFTAG_IMAGELENGTH, &h );

    npixels = w * h;

    raster = (uint32*) _TIFFmalloc( npixels * sizeof(uint32) );

    if (!TIFFReadRGBAImage( tiff, w, h, raster, 0 ))
    {

        _TIFFfree( raster );
        TIFFClose( tiff );

        return 0;
    }
	Uint8 mr = TIFFGetR( raster[0] ), mg = TIFFGetG( raster[0] ), mb = TIFFGetB( raster[0] );
	SDL_Surface *rv = SDL_CreateRGBSurface( SDL_SWSURFACE, w, h, 24, 0, 0, 0, 0 );
	if ( !back ) SDL_SetColorKey( rv, SDL_SRCCOLORKEY, SDL_MapRGB( rv->format, mr, mg, mb ) );
	Uint8 *ptr = (Uint8*) rv->pixels + ( h - 1 ) * rv->pitch;
	int pos = 0;
    for (uint32 i = 0; i < h; i++)
    {
		Uint8 *prevPtr = ptr;
		if ( mirror ) pos += w;
        for (uint32 j = 0; j < w; j++)
        {
        	if ( mirror ) pos--;
            unsigned char alpha = (unsigned char)TIFFGetA(raster[pos]);
            if (alpha < 127)
            {
                ptr[0] = mb;
                ptr++;
                ptr[0] = mg;
                ptr++;
                ptr[0] = mr;
                ptr++;
            }
            else
            {
                ptr[0] = (unsigned char)TIFFGetB(raster[pos]);
                ptr++;
                ptr[0] = (unsigned char)TIFFGetG(raster[pos]);
                ptr++;
                ptr[0] = (unsigned char)TIFFGetR(raster[pos]);
                ptr++;
            }
            if ( !mirror ) pos++;
        }
        ptr = prevPtr - rv->pitch;
        if ( mirror ) pos += w;
    }

    _TIFFfree( raster );

    TIFFClose( tiff );
	return rv;
}
