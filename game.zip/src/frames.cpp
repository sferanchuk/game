#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "g15.h"

#include <SDL/SDL_thread.h>

//Tcl_Mutex tclMutex;

FrameData fd;

void PrintMessage( const char *buf )
{
	SDL_LockMutex( fd.modMutex );
	fd.modFlag = 1;
	fd.messageBuf += buf;
	SDL_UnlockMutex( fd.modMutex );
}

void AddChoice( string variable, string text, int value )
{
	Choice c;
	c.variable = variable;
	c.text = text;
	c.value = value;
	SDL_LockMutex( fd.modMutex );
	fd.modFlag = 1;
	fd.choice_add.push_back( c );
	SDL_UnlockMutex( fd.modMutex );
}

void RemoveChoice( string variable )
{
	SDL_LockMutex( fd.modMutex );
	fd.modFlag = 1;
	fd.choice_remove.push_back( variable );
	SDL_UnlockMutex( fd.modMutex );
}

int GetChoice( string variable )
{
	map<string,int>::iterator it;
	int rv;
	SDL_LockMutex( fd.modMutex );
	it = fd.variables.find( variable );
	if ( it == fd.variables.end() ) rv = -1;
	else rv = (*it).second;
	SDL_UnlockMutex( fd.modMutex );
	return rv;
}
	
static Tcl_Interp *interp = NULL;
static FILE *dfile;

static char *cp1251[128] = {
"\\u0402", "\\u0403", "\\u201A", "\\u0453", "\\u201E", "\\u2026", "\\u2020", "\\u2021",
"\\u20AC", "\\u2030", "\\u0409", "\\u2039", "\\u040A", "\\u040C", "\\u040B", "\\u040F",
"\\u0452", "\\u2018", "\\u2019", "\\u201C", "\\u201D", "\\u2022", "\\u2013", "\\u2014",
"\\u0098", "\\u2122", "\\u0459", "\\u203A", "\\u045A", "\\u045C", "\\u045B", "\\u045F",
"\\u00A0", "\\u040E", "\\u045E", "\\u0408", "\\u00A4", "\\u0490", "\\u00A6", "\\u00A7",
"\\u0401", "\\u00A9", "\\u0404", "\\u00AB", "\\u00AC", "\\u00AD", "\\u00AE", "\\u0407",
"\\u00B0", "\\u00B1", "\\u0406", "\\u0456", "\\u0491", "\\u00B5", "\\u00B6", "\\u00B7",
"\\u0451", "\\u2116", "\\u0454", "\\u00BB", "\\u0458", "\\u0405", "\\u0455", "\\u0457",
"\\u0410", "\\u0411", "\\u0412", "\\u0413", "\\u0414", "\\u0415", "\\u0416", "\\u0417",
"\\u0418", "\\u0419", "\\u041A", "\\u041B", "\\u041C", "\\u041D", "\\u041E", "\\u041F",
"\\u0420", "\\u0421", "\\u0422", "\\u0423", "\\u0424", "\\u0425", "\\u0426", "\\u0427",
"\\u0428", "\\u0429", "\\u042A", "\\u042B", "\\u042C", "\\u042D", "\\u042E", "\\u042F",
"\\u0430", "\\u0431", "\\u0432", "\\u0433", "\\u0434", "\\u0435", "\\u0436", "\\u0437",
"\\u0438", "\\u0439", "\\u043A", "\\u043B", "\\u043C", "\\u043D", "\\u043E", "\\u043F",
"\\u0440", "\\u0441", "\\u0442", "\\u0443", "\\u0444", "\\u0445", "\\u0446", "\\u0447",
"\\u0448", "\\u0449", "\\u044A", "\\u044B", "\\u044C", "\\u044D", "\\u044E", "\\u044F" };

static string tcl_convert( string s )
{
	string rv = "\"";
	for ( int c = 0; c < s.size(); c++ )
	{
		int ch = (unsigned char)( s[c] );
		if ( ch == '\"' ) rv.append( "\\\"" );
		else if ( ch == '\\' ) rv.append( "\\\\" );
		else if ( ch == '\n' ) rv.append( "\\n" );
		else if ( ch > 127 ) rv.append( cp1251[ ch - 128] );
		else rv.append( 1, (char)ch );
	}
	rv.append( "\"" );
	return rv;
}

void Eval( const char *cmd )
{
	int status = Tcl_Eval(interp, cmd );
	if ( status != TCL_OK ) 
	{
		Tcl_Obj *options = Tcl_GetReturnOptions( interp, status );  
		Tcl_Obj *key = Tcl_NewStringObj( "-errorinfo", -1 );
    	Tcl_Obj *stackTrace;
    	Tcl_IncrRefCount( key );
    	Tcl_DictObjGet( NULL, options, key, &stackTrace );
    	Tcl_DecrRefCount( key);
 		fprintf( stderr, "Error: %s\n", Tcl_GetString( stackTrace ) );
	}
}

//static unsigned int __stdcall ThreadEntry( void* p )
static unsigned int ThreadEntry( void* p )
{
	dfile = stderr;
	int cnt = 10;	
	
	interp = Tcl_CreateInterp();
	if (interp == NULL) {
		fprintf( dfile, "Unable to initialize Tcl.\n" );
		exit(1);
	}
	if ( Tcl_Init( interp ) == TCL_ERROR )
	{
		fprintf( dfile, "error initializing tcl: %s\n", Tcl_GetStringResult( interp ) );
		exit(1);
	}
	if ( Tk_Init( interp ) == TCL_ERROR )
	{
		fprintf( dfile, "error initializing tk: %s\n", Tcl_GetStringResult( interp ) );
		exit(1);
	}
    Tcl_StaticPackage(interp, "Tk", Tk_Init, Tk_SafeInit);
	
	if ( Tcl_EvalFile( interp, "tks.tcl" ) == TCL_ERROR )
	{
		fprintf( dfile, "error loading script\n" );
		exit( 1 );
	}
	
	//Tk_MainLoop();
    while ( Tk_GetNumMainWindows() > 0 ) 
	{
		Tcl_DoOneEvent(0);
		if ( !fd.modMutex ) continue;
		SDL_LockMutex( fd.modMutex );
        if ( fd.modFlag )
		{
			if ( fd.messageBuf.size() )
			{
				string cmd = "$t insert end " + tcl_convert( fd.messageBuf );
				fd.messageBuf.clear();
				Eval( cmd.data() );
			}
			if ( fd.choice_add.size() )
			{
				for ( int cc = 0; cc < fd.choice_add.size(); cc++ )
				{
					Choice& ch = fd.choice_add[cc];
					string cmd1 = "checkbutton $w."
						+ ch.variable
						+ " -text " 
						+ tcl_convert( ch.text )
						+ " -variable "
						+ ch.variable;
					string cmd2 = "pack $w."
						+ ch.variable
						+ " -side top -anchor w" ;
					Eval( cmd1.data() );
					Eval( cmd2.data() );
					fd.variables[ ch.variable ] = ch.value;
					Tcl_LinkVar( interp, ch.variable.data(), (char *) &( fd.variables[ ch.variable ] ), TCL_LINK_INT);
				}
				fd.choice_add.clear();
			}
			if ( fd.choice_remove.size() )
			{
				for ( int cc = 0; cc < fd.choice_remove.size(); cc++ )
				{
					Eval( ( "destroy $w." + fd.choice_remove[cc] ).data() );
					fd.variables[ fd.choice_remove[cc] ] = -1;
				}
				fd.choice_remove.clear();
			}
			//Eval( "destroy $w.b" );
			//Tcl_Eval( interp, "set cb $cb" );
			//Tcl_Eval( interp, "focus -force .check" );
			//Tcl_DoOneEvent( TCL_DONT_WAIT );
			//Tcl_MutexLock( &tclMutex );
		
			fd.modFlag = 0;
		}
		SDL_UnlockMutex( fd.modMutex );
    }

	if (interp != NULL) {
		Tcl_DeleteInterp(interp);
	}
	interp = NULL;

	return 0;
}

/*
int TKStep()
{
    if ( Tk_GetNumMainWindows() > 0 ) 
	{
		Tcl_DoOneEvent(0);
	}
}
*/

int RunTK()
{
	ThreadEntry( 0 );
	//TKStep();
	//SDL_CreateThread( ThreadEntry, 0 );
	/*
	if ( Tcl_CreateThread( &tclId, ThreadEntry, 0, TCL_THREAD_STACK_DEFAULT, TCL_THREAD_NOFLAGS ) == TCL_ERROR )
	{
		fprintf( stderr, "error creating thread\n" );
		exit( 1 );
	}
	*/
	return 1;
}


	
