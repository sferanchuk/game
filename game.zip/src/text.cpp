
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <string>
#include <vector>

using namespace std;

#include <SDL/SDL.h>

#include "g15.h"

extern SDL_Surface *screen;
extern int cursX, cursY;
extern int cursNum;


SDL_Surface *SDL_LoadTIFF( const char *filename, bool back = false, bool mirror = false );

static char *theAlphabet[] = { 
   "�����Ũ�������������������������� ", 
   "��������������������������������",
   "ABCDEFGHIJKLMNOPQRSTUVWXYZ,./<>?;':\"[]{}",
   "abcdefghijklmnopqrstuvwxyz`~!@#$%^&*()",
   "01234567890-_=+\\|", 
   0 };

TextOutput::TextOutput()
{
	font = SDL_LoadTIFF( "img/t1.tif" );
	alphabet = theAlphabet;
}

TextOutput::~TextOutput()
{
	SDL_FreeSurface( font );
	for ( int mc = 0; mc < message.size(); mc++ )
		SDL_FreeSurface( message[mc].image );
}


SDL_Surface *TextOutput::printText( int x, int y, const char *text )
{
	int letterHeight = 32;
	int letterWidth = 11;
	struct { int left; int top; } fb[] = 
		{ { 31, 19 }, { 31, 64 }, { 30, 108 }, { 31, 152 }, { 31, 196 } };
	SDL_Rect rl = { 17, 19, 12, 32 };
	SDL_Rect rr = { 584, 19, 12, 32 };
   	SDL_Surface *ts = SDL_CreateRGBSurface( SDL_SWSURFACE, 640, 480, 24, 0, 0, 0, 0 );
	SDL_SetColorKey( ts, SDL_SRCCOLORKEY, SDL_MapRGB( ts->format, 255, 255, 255 ) );
	memset( ts->pixels, 255, 480 * ts->pitch );
	int cl = x;
	int length = strlen( text ) * letterWidth + 24;
	if ( cl + length > 640 ) cl = 640 - length;
	int ct = y;

	SDL_Rect srcRect, destRect;
	srcRect = rl;
    destRect.x = cl;
    destRect.y = ct;
    destRect.w = rl.w;
    destRect.h = letterHeight;
	SDL_BlitSurface( font, &srcRect, ts, &destRect );
	cl += rl.w;

	const unsigned char *p = ( const unsigned char* )text;
	do
	{
		if ( !*p ) break;
		int c = *p;
		if ( c == '\n' )
		{
			cl = x;
			ct = ct + letterHeight;
			p++;
			continue;
		}
		int fl = 0;
		int ft;
	    while ( alphabet[fl] )
	    {
	    	char *as = strchr( alphabet[fl], c );
	    	if ( as )
	    	{
	    		ft = as - alphabet[fl];
	    		break;
	    	}
	    	fl++;
	    }
	    if ( !alphabet[fl] )
	    {
	    	cl += letterWidth;
	    	p++;
	    	continue;
	    }
	    srcRect.x = fb[fl].left + ft * letterWidth;
	    srcRect.y = fb[fl].top;
	    srcRect.w = letterWidth;
	    srcRect.h = letterHeight;
	    destRect.x = cl;
	    destRect.y = ct;
	    destRect.w = letterWidth;
	    destRect.h = letterHeight;
		
		SDL_BlitSurface( font, &srcRect, ts, &destRect );
		cl += letterWidth;
		p++;
	}
	while ( 1 );

	srcRect = rr;
    destRect.x = cl;
    destRect.y = ct;
    destRect.w = rr.w;
    destRect.h = letterHeight;
	SDL_BlitSurface( font, &srcRect, ts, &destRect );
	cl += rr.w;
	SDL_Surface *rv = SDL_DisplayFormat( ts );
	SDL_FreeSurface( ts );
	return rv;
}

void TextOutput::Say( int x, int y, int delay, const char *text )
{
	message.resize( message.size() + 1 );
	message.back().image = printText( x, y, text );
	message.back().delay = delay;
}

void TextOutput::Draw()
{
	SDL_Rect rect;
	rect.x = 0;
	rect.y = 0;
	rect.w = 640;
	rect.h = 480;

	for ( int mc = 0; mc < message.size(); )
	{
		if ( message[mc].delay > 0 )
		{
   			SDL_BlitSurface( message[mc].image, NULL, screen, &rect );
   			message[mc].delay--;
   			mc++;
   		}
   		else
   		{
        	SDL_FreeSurface( message[mc].image );
        	message.erase( message.begin() + mc );
        }
    }
}

CursorSet::CursorSet()
{
	curs[0] = SDL_LoadTIFF( "img/curs1.tif" );
	curs[1] = SDL_LoadTIFF( "img/curs2.tif" );
	curs[2] = SDL_LoadTIFF( "img/curs3.tif" );
	hotSpot[0][0] = 0;
	hotSpot[0][1] = 0;
	hotSpot[1][0] = 10;
	hotSpot[1][1] = 3;
	hotSpot[2][0] = 9;
	hotSpot[2][1] = 9;
	offsetX = offsetY = 0;
}

CursorSet::~CursorSet()
{
	SDL_FreeSurface( curs[0] );
	SDL_FreeSurface( curs[1] );
	SDL_FreeSurface( curs[2] );
}

void CursorSet::Draw( World *world )
{
	if ( world->player->alcohol )
	{
		int lim = world->player->alcohol * 10;
		int s1 = rand() % 6 - 3;
		int s2 = rand() % 6 - 3;
		offsetX += s1;
		if ( offsetX > lim ) offsetX = lim;
		if ( offsetX < -lim ) offsetX = -lim;
		offsetY += s2;
		if ( offsetY > lim ) offsetY = lim;
		if ( offsetY < -lim ) offsetY = -lim;
	}
	else offsetX = offsetY = 0;

	SDL_Rect srcRect, destRect;
	destRect.x = cursX + hotSpot[cursNum][0] + offsetX;
	destRect.y = cursY + hotSpot[cursNum][1] + offsetY;
    destRect.w = curs[cursNum]->w;;
    destRect.h = curs[cursNum]->h;
	srcRect.x = 0;
	srcRect.y = 0;
    srcRect.w = destRect.w;
    srcRect.h = destRect.h;
	SDL_BlitSurface( curs[cursNum], &srcRect, screen, &destRect );
}
