#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <SDL/SDL_thread.h>

#include "g15.h"

SDL_Surface *loadSurface( const string& filename, bool back = false, bool mirror = false );

const int tw = 16, th = 16, tscale = 80, ytscale = 10;

static int AddColor( ClientData client_data, Tcl_Interp *interp, int objc, Tcl_Obj * CONST objv[] )
{
	if ( objc != 3 ) 
	{
		Tcl_AddErrorInfo( interp, "color: wrong number of arguments" );
		return TCL_ERROR;
	}
	int narg;
	Tcl_Obj **arg;
	Tcl_ListObjGetElements( interp,  objv[2], &narg, &arg );
	if ( narg < 3 )
	{
		Tcl_AddErrorInfo( interp, "color: incorrect color" );
		return TCL_ERROR;
	}
	Color c;
	Tcl_GetInt( interp, Tcl_GetString( arg[0] ), &c.r );
	Tcl_GetInt( interp, Tcl_GetString( arg[1] ), &c.g );
	Tcl_GetInt( interp, Tcl_GetString( arg[2] ), &c.b );
	((Map*)client_data)->color[ Tcl_GetString( objv[1] )[0] ] = c;
	return TCL_OK;
}

static int ProcessMap( ClientData client_data, Tcl_Interp *interp, int objc, Tcl_Obj * CONST objv[] )
{
	if ( objc < 4 ) 
	{
		Tcl_AddErrorInfo( interp, "rect: wrong number of arguments" );
		return TCL_ERROR;
	}
	const char *cmd = Tcl_GetString( objv[1] );
	Map *m = (Map*)client_data;
	int narg;
	Tcl_Obj **arg;
	Tcl_ListObjGetElements( interp,  objv[3], &narg, &arg );
	int h = narg, w = strlen( Tcl_GetString( arg[0] ) );
	if ( strcmp( cmd, "tile" ) == 0 || strcmp( cmd, "obj" ) == 0 )
	{
		SDL_Surface *surface = SDL_CreateRGBSurface( SDL_SWSURFACE, w, h, 24, 0, 0, 0, 0 );
		Uint8 *ptr = (Uint8*) surface->pixels;
    	for (int i = 0; i < h; i++)
    	{
			Uint8 *prevPtr = ptr;
			const char *src = Tcl_GetString( arg[i] );
			if ( strlen( src ) != w )
			{
				Tcl_AddErrorInfo( interp, "rect: unaligned map" );
				return TCL_ERROR;
			}
	        for (int j = 0; j < w; j++)
    	    {
        		map<int,Color>::iterator it = m->color.find( src[j] );
				if ( it == m->color.end() )
				{
					Tcl_AddErrorInfo( interp, "rect: undefined color" );
					return TCL_ERROR;
				}
                ptr[0] = (*it).second.b;
                ptr[1] = (*it).second.g;
                ptr[2] = (*it).second.r;
                ptr+= 3;
			}
            ptr = prevPtr + surface->pitch;
	    }
		const char *name = Tcl_GetString( objv[2] );
		if ( strcmp( cmd, "tile" ) == 0 )
		{
			Tile t;
			t.surface = surface;
			t.transparent = 0;
			if ( objc > 4 ) Tcl_GetInt( interp, Tcl_GetString( objv[4] ), &(t.transparent) );
			m->tile[ name[0] ] = t;
		}
		else //object
		{
			if ( m->repository.find( name ) == m->repository.end() )
			{
				RepObject ro;
				ro.name = name;
				m->repository[ name ] = ro;
			}
			m->repository[ name ].tile = surface;
		}
	}
	else if ( strcmp( cmd, "map" ) == 0 )
	{
		SDL_Surface *surface = SDL_CreateRGBSurface( SDL_SWSURFACE, w * tw, h * th, 24, 0, 0, 0, 0 );
		m->amap.resize( h );
		for ( int i = 0; i < h; i++ )
		{
			const char *src = Tcl_GetString( arg[i] );
			if ( strlen( src ) != w )
			{
				Tcl_AddErrorInfo( interp, "rect: unaligned map" );
				return TCL_ERROR;
			}
			m->amap[i].resize( w );
			for ( int j = 0; j < w; j++ )
			{
        		map<int,Tile>::iterator it = m->tile.find( src[j] );
				if ( it == m->tile.end() )
				{
					Tcl_AddErrorInfo( interp, "rect: undefined tile" );
					return TCL_ERROR;
				}
				SDL_Surface *tile = (*it).second.surface;
				SDL_Rect rect;
				rect.x = j * tw;
				rect.y = i * th;
				rect.w = tile->w;
				rect.h = tile->h;
				SDL_Rect srcRect;
				srcRect.x = 0;
				srcRect.y = 0;
				srcRect.w = rect.w;
				srcRect.h = rect.h;
				SDL_BlitSurface( tile, &srcRect, surface, &rect );
				m->amap[i][j] = (*it).second.transparent;
			}
		}
		m->msurf = surface;
	}
	else
	{
		Tcl_AddErrorInfo( interp, "rect: incorrect command" );
		return TCL_ERROR;
	}
	return TCL_OK;
}

static int AddProj( ClientData client_data, Tcl_Interp *interp, int objc, Tcl_Obj * CONST objv[] )
{
	if ( objc < 4 ) 
	{
		Tcl_AddErrorInfo( interp, "proj: wrong number of arguments" );
		return TCL_ERROR;
	}
	Map *m = (Map*)client_data;
	int narg;
	Tcl_Obj **arg;
	Tcl_ListObjGetElements( interp,  objv[1], &narg, &arg );
	if ( narg != 4 )
	{
		Tcl_AddErrorInfo( interp, "proj: rect expected" );
		return TCL_ERROR;
	}
	Projection proj;
	Tcl_GetInt( interp, Tcl_GetString( arg[0] ), &( proj.c[ mLeft ] ) );
	Tcl_GetInt( interp, Tcl_GetString( arg[1] ), &( proj.c[ mUp ] ) );
	Tcl_GetInt( interp, Tcl_GetString( arg[2] ), &( proj.c[ mRight ] ) );
	Tcl_GetInt( interp, Tcl_GetString( arg[3] ), &( proj.c[ mDown ] ) );
	const char *ori = Tcl_GetString( objv[2] );
	if ( strcmp( ori, "left" ) == 0 ) proj.orientation = mLeft;
	else if ( strcmp( ori, "top" ) == 0 ) proj.orientation = mUp;
	else if ( strcmp( ori, "right" ) == 0 ) proj.orientation = mRight;
	else if ( strcmp( ori, "bottom" ) == 0 ) proj.orientation = mDown;
	proj.surface = loadSurface( Tcl_GetString( objv[3] ), true );
	if ( !proj.surface )
	{
		Tcl_AddErrorInfo( interp, "proj: undefined file" );
		return TCL_ERROR;
	}


	m->proj.push_back( proj );
	return TCL_OK;
}

#ifndef F_OK
static int access( const char *fname, int flag )
{
	FILE *ifile = fopen( fname, "rb" );
	if ( ifile )
	{
		fclose( ifile );
		return 0;
	}
	return 1;
}
#endif

static bool ImageExists( string name )
{
	return access( ("img/" + name ).c_str(), 0 ) == 0;
}

static int AddType( ClientData client_data, Tcl_Interp *interp, int objc, Tcl_Obj * CONST objv[] )
{
	if ( objc < 2 ) 
	{
		Tcl_AddErrorInfo( interp, "type: wrong number of arguments" );
		return TCL_ERROR;
	}
	Map *m = (Map*)client_data;
	const char *name = Tcl_GetString( objv[1] );
	if ( m->repository.find( name ) == m->repository.end() )
	{
		RepObject ro;
		ro.name = name;
		m->repository[ name ] = ro;
	}
	RepObject& ro = m->repository[name];
	bool mirror = false;
	for ( int oc = 2; oc < objc; oc+= 2 )
	{
		if ( strcmp( Tcl_GetString( objv[oc] ), "-ypos" ) == 0 )
		{
			int ypos;
			Tcl_GetInt( interp, Tcl_GetString( objv[ oc + 1 ] ), &ypos );
			if ( ro.pic ) ro.pic->y = ypos;
			for ( int pc = 0; pc < ro.phase.size(); pc++ )
			{
				ro.phase[pc]->y = ypos;
				ro.mirror_phase[pc]->y = ypos;
			}
		}
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-pic" ) == 0 )
		{
			ro.pic = new Sprite( loadSurface( Tcl_GetString( objv[3] ) ) );
		}
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-mirror" ) == 0 )
		{
			mirror = true;
		}
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-phases" ) == 0 )
		{
			const char *tag = Tcl_GetString( objv[ oc + 1 ] );
			char buf[20];
			sprintf( buf, "%s.tif", tag );
			if ( ImageExists( buf ) )
			{
				ro.phase.push_back( new Sprite( loadSurface( buf, false, mirror ) ) );
				ro.mirror_phase.push_back( new Sprite( loadSurface( buf, false, !mirror ) ) );
			}
			else
			{
				int cnt = 0;
				do
				{
					sprintf( buf, "%s-%d.tif", tag, cnt );
					if ( !ImageExists( buf ) ) break;
					ro.phase.push_back( new Sprite( loadSurface( buf, false, mirror ) ) );
					ro.mirror_phase.push_back( new Sprite( loadSurface( buf, false, !mirror ) ) );
					cnt++;
				}
				while ( 1 );
			}
		}		
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-width" ) == 0 )
		{
			Tcl_GetInt( interp, Tcl_GetString( objv[ oc + 1 ] ), &( ro.w ) );
		}
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-height" ) == 0 )
		{
			Tcl_GetInt( interp, Tcl_GetString( objv[ oc + 1 ] ), &( ro.h ) );
		}
	}
	return TCL_OK;
}

static int AddObj( ClientData client_data, Tcl_Interp *interp, int objc, Tcl_Obj * CONST objv[] )
{
	if ( objc < 2 ) 
	{
		Tcl_AddErrorInfo( interp, "obj: wrong number of arguments" );
		return TCL_ERROR;
	}
	Map *m = (Map*)client_data;
	const char *name = Tcl_GetString( objv[1] );
	m->object.push_back( MapObject() );
	MapObject& mo = m->object.back();
	mo.name = name;
	if ( strcmp( name, "player" ) == 0 ) m->player = & mo;
	for ( int oc = 2; oc < objc; oc+= 2 )
	{
		if ( strcmp( Tcl_GetString( objv[oc] ), "-pos" ) == 0 )
		{
			int narg;
			Tcl_Obj **arg;
			Tcl_ListObjGetElements( interp,  objv[ oc + 1 ], &narg, &arg );
			if ( narg != 2 )
			{
				Tcl_AddErrorInfo( interp, "obj: pos expected" );
				return TCL_ERROR;
			}
			Tcl_GetInt( interp, Tcl_GetString( arg[0] ), &mo.x );
			Tcl_GetInt( interp, Tcl_GetString( arg[1] ), &mo.y );
		}
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-type" ) == 0 )
		{
			const char *type = Tcl_GetString( objv[ oc + 1 ] );
			if ( m->repository.find( type ) == m->repository.end() )
			{
				Tcl_AddErrorInfo( interp, "obj: undefined type" );
				return TCL_ERROR;
			}
			mo.type = &( m->repository[type] );
			if ( mo.type->pic ) mo.pic = mo.type->pic;
			else mo.pic = mo.type->phase[0];
		}
		else if ( strcmp( Tcl_GetString( objv[oc] ), "-dir" ) == 0 )
		{
			string dir = Tcl_GetString( objv[ oc + 1 ] );
			if ( dir == "left" ) mo.dir = mLeft;
			else if ( dir == "right" ) mo.dir = mRight;
			else if ( dir == "up" ) mo.dir = mUp;
			else if ( dir == "down" ) mo.dir = mDown;
			else mo.dir = mStay;
		}
	}
	return TCL_OK;
}

int LoadMap( Map& map )
{
	map.player = 0;
	Tcl_Interp * interp = Tcl_CreateInterp();
	if ( interp == NULL ) 
	{
		fprintf(stderr, "Unable to initialize Tcl.\n");
		return 0;
	}

	if ( Tcl_CreateObjCommand( interp, "color", AddColor, (ClientData) (&map), NULL) == NULL ) 
	{
		fprintf(stderr, "Error creating command.\n");
		return 0;
	}
	if ( Tcl_CreateObjCommand( interp, "rect", ProcessMap, (ClientData) (&map), NULL) == NULL ) 
	{
		fprintf(stderr, "Error creating command.\n");
		return 0;
	}
	if ( Tcl_CreateObjCommand( interp, "proj", AddProj, (ClientData) (&map), NULL) == NULL ) 
	{
		fprintf(stderr, "Error creating command.\n");
		return 0;
	}
	if ( Tcl_CreateObjCommand( interp, "type", AddType, (ClientData) (&map), NULL) == NULL ) 
	{
		fprintf(stderr, "Error creating command.\n");
		return 0;
	}
	if ( Tcl_CreateObjCommand( interp, "obj", AddObj, (ClientData) (&map), NULL) == NULL ) 
	{
		fprintf(stderr, "Error creating command.\n");
		return 0;
	}
	int status = Tcl_EvalFile(interp, "map.tcl" );
	//int status = Tcl_EvalFile(interp, "simple.tcl" );
	if ( status != TCL_OK ) 
	{
		Tcl_Obj *options = Tcl_GetReturnOptions( interp, status );  
		Tcl_Obj *key = Tcl_NewStringObj( "-errorinfo", -1 );
    	Tcl_Obj *stackTrace;
    	Tcl_IncrRefCount( key );
    	Tcl_DictObjGet( NULL, options, key, &stackTrace );
    	Tcl_DecrRefCount( key);
 		fprintf( stderr, "Error: %s\n", Tcl_GetString( stackTrace ) );
		return 0;
	}
	Tcl_DeleteInterp(interp);
	if ( !map.player )
	{
		fprintf( stderr, "Error: player undefined in map\n" );
		return 0;
	}
	map.offsetx = map.offsety = 0;
	return 1;
}

static int cmdMatrix[5][5] = { { mStay },
    { mStay, mDown, mLeft, mUp, mRight },
	{ mStay, mLeft, mUp, mRight, mDown },
	{ mStay, mUp, mRight, mDown, mLeft },
	{ mStay, mRight, mDown, mLeft, mUp } };
	
static int projMatrix[5][5] = { { 0 },
	{ 0, 0, 1, 0, -1 },
	{ 0, -1, 0, 1, 0 },
	{ 0, 0, -1, 0, 1 },
	{ 0, 1, 0, -1, 0 } };
	
static int moveSign[2][5] = { { 0, -1, 0, 1, 0 }, { 0, 0, -1, 0, 1 } };	

int TryToMove( Map& m, int cmd )
{
	m.player->moving = false;
	if ( m.mode == 1 ) cmd = cmdMatrix[ m.orientation ][ cmd ];
	int nx = m.player->x + moveSign[0][cmd];
	int ny = m.player->y + moveSign[1][cmd];
	if ( ny < 0 || ny >= m.amap.size() ) return 0;
	if ( nx < 0 || nx >= m.amap[0].size() ) return 0;
	if ( !m.amap[ny][nx] ) return 0;
	for ( MapObjectIter it = m.object.begin(); it != m.object.end(); it++ )
	{
		if ( (*it).type 
			&& (*it).x <= nx && (*it).x + (*it).type->w > nx
			&& (*it).y <= ny && (*it).y + (*it).type->h > ny 
			&& (*it).name != "player" ) return 0;
	}			
	/*
	m.player->x = nx;
	m.player->y = ny;
	if ( projMatrix[ m.orientation ][ cmd ] == -1 ) m.player->pic = m.player->type->phase[0];
	else if ( projMatrix[ m.orientation ][ cmd ] == 1 ) m.player->pic = m.player->type->mirror_phase[0];
	*/
	m.player->dir = cmd;
	m.player->moving = true;
	return 1;
}

static Projection *GetProj( Map& m, int x, int y )
{
	for ( int pc = 0; pc < m.proj.size(); pc++ )
	{
		if ( m.proj[pc].c[ mLeft ] <= x
			&& m.proj[pc].c[ mRight ] >= x
			&& m.proj[pc].c[ mUp ] <= y
			&& m.proj[pc].c[ mDown ] >= y ) 
		{
			return  &( m.proj[pc] );
		}
	}
	return 0;
}

static bool DrawBands( Map& m, SDL_Surface *surface, int cycle )
{
	if ( !m.player->moving || !cycle ) return false;
	Projection *proj = GetProj( m, m.player->x, m.player->y );
	Projection *nproj = GetProj( m, 
		m.player->x + moveSign[0][m.player->dir], 
		m.player->y + moveSign[1][m.player->dir] );
	if ( proj == nproj ) return false;
	const int bandWidth = 80;
	for ( int ic = 0; ic < 640 / bandWidth; ic++ )
	{
		SDL_Rect rect;
		rect.x = ic * bandWidth + bandWidth * cycle / 4;
		rect.y = 0;
		rect.w = ( 4 - cycle ) * bandWidth / 4;
		rect.h = 480;
		SDL_BlitSurface( proj->surface, &rect, surface, &rect );
	}
	for ( int ic = 0; ic < 640 / bandWidth; ic++ )
	{
		SDL_Rect rect;
		rect.x = ic * bandWidth;
		rect.y = 0;
		rect.w = ( cycle ) * bandWidth / 4;
		rect.h = 480;
		SDL_BlitSurface( nproj->surface, &rect, surface, &rect );
	}
	return true;
}

int DrawProj( Map& m, SDL_Surface *surface, int cycle )
{
	if ( DrawBands( m, surface, cycle ) ) return 1;
	
	Projection *proj = GetProj( m, m.player->x, m.player->y );
	if ( !proj ) return 0;
	m.orientation = proj->orientation;
	SDL_Rect srcrect;
	srcrect.x = 0;
	srcrect.y = 0;
	srcrect.w = 640;
	srcrect.h = 480;
	SDL_Rect destrect;
	destrect.x = 0;
	destrect.y = 0;
	destrect.w = 640;
	destrect.h = 480;
	
	SDL_BlitSurface( proj->surface, &srcrect, surface, &destrect );
	
	int ubc[5] = { 0, mLeft, mUp, mRight, mDown };
	int lbc[5] = { 0, mRight, mDown, mLeft, mUp };
	int dc[5] = { 0, -1, -1, 1, 1 };
	int ub = proj->c[ ubc[ proj->orientation ] ];
	int lb = proj->c[ lbc[ proj->orientation ] ];
	int sign = dc[ proj->orientation ];
	int lc = ub + sign;
	
	do {
		MapObjectIter it = m.object.end(); 
		do
		{
			it--;
			MapObject& mo = (*it);
			//mo.visible = false;
			if ( !mo.type ) continue;
			if ( mo.x + mo.type->w < proj->c[ mLeft ] - 1 ) continue;
			if ( mo.x > proj->c[ mRight ] + 1) continue;
			if ( mo.y + mo.type->h < proj->c[ mUp ] - 1 ) continue;
			if ( mo.y > proj->c[ mDown ] + 1 ) continue;
			//mo.visible = true;
			int coo[2];
			coo[0] = mo.x;
			coo[1] = mo.y;
			int df[5] = { 0, 0, 1, 0, 1 };
			if ( lc != coo[ df[ proj->orientation ] ] ) continue;
			
			SDL_Surface *pic;
			SDL_Rect rect;
			rect.y = 260;
			SDL_Rect srcRect;
			if ( mo.type->pic )
			{
				pic = mo.type->pic->surface;
				rect.y = mo.type->pic->y;
			}
			else 
			{
				int np = mo.type->phase.size();
				if ( !np ) continue;
				int sign = projMatrix[ proj->orientation ][ mo.dir ];
				if ( sign == 0 && mo.pic ) 
				{
					pic = mo.pic->surface;
					if ( mo.pic->y ) rect.y = mo.pic->y;
				}
				else if ( sign == 1 ) pic = mo.type->mirror_phase[ cycle % np ]->surface;
				else pic = mo.type->phase[ cycle % np ]->surface;
				rect.y +=  ( ub - lc ) * ytscale * dc[ proj->orientation ];
			}
			rect.w = pic->w;
			rect.h = pic->h;
			srcRect.x = 0;
			srcRect.y = 0;
			int leftbc[5] = { 0, mDown, mLeft, mUp, mRight };
			int leftsign[5] = { 0, -1, 1, 1, -1 };
			rect.x = ( coo[ 1 - df[ proj->orientation ] ] 
				- proj->c[ leftbc[ proj->orientation ] ] ) 
				* leftsign[ proj->orientation ] * tscale;
			if ( mo.moving && cycle ) 
			{
				rect.x += tscale * cycle * projMatrix[ proj->orientation ][ mo.dir ] / 4;
				if ( lc == ub && mo.dir == proj->orientation 
					|| lc == lb && lbc[ mo.dir ] == proj->orientation )
				{
					rect.w = rect.w * ( 4 - cycle ) / 4;
				}
			}
			if ( mo.moving && cycle
				&& ( lc == ub + sign && lbc[ mo.dir ] == proj->orientation 
					|| lc == lb - sign && mo.dir == proj->orientation ) )
			{
				rect.w = rect.w * ( cycle ) / 4;
			}
			else if ( lc == ub + sign || lc == lb - sign ) continue;
			
			if ( rect.x < 0 )
			{
				rect.w += rect.x;
				if ( short( rect.w ) < 0 ) rect.w = 0;
				srcRect.x -= rect.x;
				rect.x = 0;
			}
			srcRect.w = rect.w;
			srcRect.h = rect.h;
			
			SDL_BlitSurface( pic, &srcRect, surface, &rect );
		}
		while ( it != m.object.begin() );
		lc -= sign;
		if ( lc == lb - 2 * sign ) break;
	}
	while ( 1 );

	return 1;
}

int DrawMap( Map& m, SDL_Surface *surface )
{
	if ( m.mode == 1 )
	{
		if ( DrawProj( m, surface, 0 ) ) return 1;
		else m.mode = 0;
	}
	SDL_Rect srcrect;
	srcrect.x = m.offsetx * tw;
	srcrect.y = m.offsety * th;
	srcrect.w = 640;
	srcrect.h = 480;
	SDL_Rect destrect;
	destrect.x = 0;
	destrect.y = 0;
	destrect.w = 640;
	destrect.h = 480;
	
	SDL_BlitSurface( m.msurf, &srcrect, surface, &destrect );
	MapObjectIter it = m.object.end(); 
	do
	{
		it--;
		if ( !(*it).type ) continue;
		/*
		(*it).visible = ( 
			abs( (*it).x - m.player.x ) < visibleSize
			abs( (*it).y - m.player.y ) < visibleSize );
		if ( !(*it).visible ) continue;	
		*/	
		SDL_Surface *tile = (*it).type->tile;
		if (!tile ) continue;
		SDL_Rect rect;
		rect.x = ( (*it).x - m.offsetx ) * tw;
		rect.y = ( (*it).y - m.offsety ) * th;
		rect.w = tile->w;
		rect.h = tile->h;
		SDL_Rect srcRect;
		srcRect.x = 0;
		srcRect.y = 0;
		srcRect.w = rect.w;
		srcRect.h = rect.h;
		SDL_BlitSurface( tile, &srcRect, surface, &rect );
	}
	while ( it != m.object.begin() );
	return 1;
}

void MoveObjects( Map& m )
{
	for ( MapObjectIter it = m.object.begin(); it != m.object.end(); it++ )
	{
		MapObject &mo = *it;
		if ( !mo.type ) continue;
		if ( !mo.moving ) continue;
		mo.x += moveSign[0][mo.dir];
		mo.y += moveSign[1][mo.dir];
		mo.moving = false;
	}
	const int maxx = 640 / tw;
	const int maxy = 480 / th;
	m.offsetx = max( min( m.player->x - maxx + 10, int( m.amap[0].size() ) - maxx ), m.offsetx );
	m.offsetx = min( max( 0, m.player->x - 10 ), m.offsetx );
	m.offsety = max( min( m.player->y - maxy + 10, int( m.amap.size() ) - maxy ), m.offsety );
	m.offsety = min( max( 0, m.player->y - 10 ), m.offsety );
}
